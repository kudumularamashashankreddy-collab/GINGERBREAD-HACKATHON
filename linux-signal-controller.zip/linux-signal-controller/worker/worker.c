/*
 * worker.c — Sample worker process for Linux Signal-Based Process Controller
 *
 * Behaviour:
 *   - Prints its PID and a startup message.
 *   - Loops, printing a heartbeat every HEARTBEAT_INTERVAL_SEC seconds.
 *   - Handles SIGTERM for graceful shutdown.
 *   - Uses fflush(stdout) after each message so output appears promptly
 *     even when stdout is not attached to a terminal.
 *
 * SIGNALS this worker handles:
 *   SIGTERM — caught; sets a flag; the main loop exits cleanly.
 *   SIGSTOP — NOT catchable (kernel-enforced); process is suspended.
 *   SIGCONT — NOT catchable as "new"; the process resumes automatically.
 *   SIGKILL — NOT catchable; process is killed immediately.
 *
 * NOTE: This worker is intentionally simple.  In a real application the
 * worker would perform meaningful work between heartbeats.
 */

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>

/* Heartbeat interval in seconds. */
#define HEARTBEAT_INTERVAL_SEC 2

/* ------------------------------------------------------------------ */
/* Signal handling                                                       */
/* ------------------------------------------------------------------ */

/*
 * g_running — checked in the main loop.
 *   Set to 0 by handle_sigterm() to request a clean shutdown.
 *   Declared volatile sig_atomic_t for async-signal-safe access.
 */
static volatile sig_atomic_t g_running = 1;

static void handle_sigterm(int signo)
{
    (void)signo;
    g_running = 0;
}

/* ------------------------------------------------------------------ */
/* Timestamp helper                                                      */
/* ------------------------------------------------------------------ */

static void print_timestamp(void)
{
    time_t    now = time(NULL);
    struct tm tm_info;
    char      buf[24];
    if (localtime_r(&now, &tm_info) != NULL) {
        strftime(buf, sizeof(buf), "%H:%M:%S", &tm_info);
        printf("%s", buf);
    } else {
        printf("??:??:??");
    }
}

/* ------------------------------------------------------------------ */
/* Main                                                                  */
/* ------------------------------------------------------------------ */

int main(void)
{
    pid_t my_pid = getpid();

    /* Install SIGTERM handler. */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_sigterm;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    if (sigaction(SIGTERM, &sa, NULL) != 0) {
        perror("worker: sigaction(SIGTERM)");
        return EXIT_FAILURE;
    }

    /* Startup message. */
    printf("  [WORKER] Started  PID=%d\n", (int)my_pid);
    printf("  [WORKER] I will print a heartbeat every %d second(s).\n",
           HEARTBEAT_INTERVAL_SEC);
    printf("  [WORKER] Send SIGTERM to stop me gracefully.\n");
    fflush(stdout);

    unsigned long beat = 0;

    while (g_running) {
        sleep(HEARTBEAT_INTERVAL_SEC);

        if (!g_running)
            break;

        beat++;
        printf("  [WORKER] PID=%-6d  beat=%-4lu  ", (int)my_pid, beat);
        print_timestamp();
        printf("  ♥\n");
        fflush(stdout);
    }

    /* Clean shutdown. */
    printf("  [WORKER] PID=%d received SIGTERM — shutting down cleanly.\n",
           (int)my_pid);
    fflush(stdout);
    return EXIT_SUCCESS;
}
