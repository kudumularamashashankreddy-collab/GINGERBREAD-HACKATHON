# VIVA.md — B.Tech CSE OS Viva Questions & Answers
# Linux Signal-Based Process Controller

---

## Q1. What is a process?

**Answer:**  
A process is a running instance of a program. It is the fundamental unit of execution in an operating system. Each process has its own private virtual address space, program counter, CPU registers, stack, heap, and file descriptors. The OS kernel manages all processes and schedules them on available CPU cores.

---

## Q2. What is a PID?

**Answer:**  
PID stands for **Process Identifier**. It is a unique integer assigned by the kernel when a process is created. PIDs are used by system calls such as `kill()`, `waitpid()`, and `getpid()` to identify a specific process. PID 1 is reserved for the init system (systemd on modern Linux). PIDs are recycled after processes exit.

---

## Q3. What are the process states in Linux?

**Answer:**  
Linux processes can be in one of these states (visible in `/proc/<PID>/stat` field 3):

| State | Char | Description |
|---|---|---|
| Running/Runnable | `R` | On the CPU or ready queue |
| Sleeping | `S` | Waiting for an event (interruptible) |
| Disk sleep | `D` | Blocked on I/O (uninterruptible) |
| Stopped | `T` | Suspended by `SIGSTOP` or `SIGTSTP` |
| Zombie | `Z` | Exited but not yet reaped by parent |
| Dead | `X` | Fully removed (rarely seen in /proc) |

---

## Q4. What is a signal?

**Answer:**  
A signal is a software interrupt delivered asynchronously to a process by the kernel or another process. Signals notify a process of an event — such as a child exiting, a keyboard interrupt, or a termination request. A process can install a custom handler function, ignore most signals, or accept the default action. `SIGKILL` and `SIGSTOP` are special — they cannot be caught or ignored.

---

## Q5. How does `kill()` work?

**Answer:**  
`kill(pid, sig)` is a system call that sends signal `sig` to process `pid`. Despite its name, it sends any signal, not just terminate. The kernel:
1. Checks that the calling process has permission (same UID, or root).
2. Delivers the signal to the target's pending signal set.
3. Returns `0` on successful delivery (not necessarily on receipt).

Example: `kill(1234, SIGTERM)` sends `SIGTERM` to process 1234.

---

## Q6. What does `SIGSTOP` do?

**Answer:**  
`SIGSTOP` (signal 19) unconditionally suspends a process. The kernel freezes the process — it is removed from the CPU scheduler's run queue and will not execute until it receives `SIGCONT`. **Critically, `SIGSTOP` cannot be caught, blocked, or ignored by the target process.** This makes it different from `SIGTSTP` (keyboard stop, Ctrl+Z), which the process can ignore.

---

## Q7. What does `SIGCONT` do?

**Answer:**  
`SIGCONT` (signal 18) resumes a stopped process. After receiving it, the process becomes eligible to run again — the CPU scheduler will eventually schedule it. It does not immediately grant CPU time. If a non-stopped process receives `SIGCONT`, it is harmlessly ignored.

---

## Q8. What does `SIGTERM` do?

**Answer:**  
`SIGTERM` (signal 15) is a polite termination request. It is the **default signal** sent by `kill <pid>` in the shell. The process **can** catch it, handle it (e.g., flush buffers, close files, free resources), and then exit — or it can even ignore it. Well-written programs handle `SIGTERM` for clean shutdown. Our worker installs a `SIGTERM` handler that sets a flag, causing the heartbeat loop to exit.

---

## Q9. What does `SIGKILL` do?

**Answer:**  
`SIGKILL` (signal 9) is an unconditional termination. Like `SIGSTOP`, it **cannot be caught, blocked, or ignored**. The kernel kills the process immediately, without giving it a chance to clean up. `SIGKILL` should be a last resort because it can leave files half-written or locks unreleased. Our controller deliberately does NOT send `SIGKILL` automatically.

---

## Q10. What is the difference between `SIGSTOP` and `SIGTERM`?

**Answer:**  

| Property | `SIGSTOP` | `SIGTERM` |
|---|---|---|
| Default action | Suspend | Terminate |
| Catchable? | **No** | Yes |
| Blockable? | **No** | Yes |
| Ignorable? | **No** | Yes |
| Process continues? | Suspended | Exits (if not caught) |

`SIGSTOP` halts a process while keeping it alive. `SIGTERM` requests it to terminate. The key distinction is that `SIGTERM` can be handled by the application.

---

## Q11. What is the difference between `SIGTERM` and `SIGKILL`?

**Answer:**  
Both terminate a process, but:
- `SIGTERM` gives the process a chance to clean up and exit gracefully.
- `SIGKILL` immediately destroys the process with no cleanup.
- `SIGTERM` can be caught/ignored; `SIGKILL` cannot.

The recommended pattern is: send `SIGTERM`, wait for graceful exit, then (if needed) escalate to `SIGKILL`. Our controller stops at `SIGTERM` and reports if the process does not exit.

---

## Q12. What is `fork()`?

**Answer:**  
`fork()` creates a new child process that is an almost identical copy of the parent. After `fork()`:
- Both parent and child continue from the same point.
- `fork()` returns `0` to the child and the child's PID to the parent.
- The child gets its own copy of the parent's address space (copy-on-write).
- File descriptors, environment variables, and signal masks are inherited.

`fork()` is the fundamental mechanism by which new processes are created in UNIX systems.

---

## Q13. What is `exec()`?

**Answer:**  
The `exec()` family of functions (`execl`, `execv`, `execvp`, etc.) replaces the current process's memory image with a new program. After a successful `exec()`:
- The process ID remains the same.
- The old code, stack, and heap are replaced with the new program's.
- `exec()` does not return on success.
- File descriptors (unless `O_CLOEXEC`) are preserved.

---

## Q14. Why do we combine `fork()` and `exec()`?

**Answer:**  
This is the standard UNIX way to launch a new program:
1. `fork()` creates a child copy of the parent process.
2. `exec()` in the child replaces its image with the target program.
3. The parent waits (using `waitpid()`) for the child to finish.

This design allows the child to set up its environment (redirect file descriptors, adjust signals) between `fork()` and `exec()` before the new program starts.

---

## Q15. What is `waitpid()`?

**Answer:**  
`waitpid(pid, &status, flags)` suspends the calling process until the specified child changes state (exits, is stopped, or is continued). It is essential for:
- **Collecting the child's exit status**.
- **Preventing zombie processes** — if the parent never calls `wait()`, the child's process table entry remains as a zombie indefinitely.

With `WNOHANG` flag: returns immediately if no child has exited yet (non-blocking polling).

---

## Q16. What is a zombie process?

**Answer:**  
A zombie is a process that has finished executing but whose entry in the process table has not been removed because the parent has not yet called `wait()`. A zombie occupies a slot in the process table and counts against the system's PID limit, but consumes no CPU or memory. Our controller prevents zombies by using a `SIGCHLD` handler and calling `waitpid(WNOHANG)` in a loop.

---

## Q17. What is an orphan process?

**Answer:**  
An orphan is a child process whose parent has exited before it. When a parent dies, its children are **reparented** to PID 1 (init/systemd). The init process periodically calls `wait()` so orphaned children do not become permanent zombies. Orphans are generally harmless, unlike zombies.

---

## Q18. What is `/proc`?

**Answer:**  
`/proc` is a **virtual filesystem** (pseudo-filesystem) in Linux. It does not correspond to any disk files — the kernel generates its contents dynamically in response to reads. It exposes:
- `/proc/<PID>/stat` — process status, state, CPU time, etc.
- `/proc/<PID>/status` — human-readable process info.
- `/proc/<PID>/maps` — memory mappings.
- `/proc/cpuinfo`, `/proc/meminfo` — system-wide info.

Our project reads `/proc/<PID>/stat` to retrieve the process name and state character.

---

## Q19. How are process permissions enforced?

**Answer:**  
The kernel enforces signal permissions using the **user ID (UID)**:
- A process can signal any process with the same real or saved UID.
- Root (UID 0) can signal any process.
- Attempting to signal a process owned by another user results in `EPERM` (Permission denied).

Our `safe_kill()` function checks the return value of `kill()` and reports `EPERM` to the user.

---

## Q20. Why can PID reuse be dangerous?

**Answer:**  
Linux recycles PIDs after processes exit. If our controller stores a PID and later tries to signal it, the original process may have exited and a completely different, unrelated process may now have the same PID. Signalling this new process is incorrect and potentially harmful. To mitigate this, our controller:
- Tracks whether each child has been reaped with `waitpid()`.
- Refuses to signal a reaped PID.
- Uses `SIGCHLD` to detect child exit as quickly as possible.

---

## Q21. How does the restart feature work?

**Answer:**  
Restart is implemented as two sequential steps:
1. **Terminate** the old worker: send `SIGTERM`, wait up to 5 seconds for it to exit, and call `waitpid()` to reap it.
2. **Launch a new worker**: `fork()` + `execl()` a fresh instance using the stored executable path.

The new process gets a completely new PID. We display both the old and new PIDs to make clear that this is a brand-new process, not a continuation of the old one.

---

## Q22. Why is restart not a Linux signal?

**Answer:**  
There is no `SIGRESTART` in Linux. Restart is an **application-level concept** — it means "stop this process and create a new one." The kernel has no concept of restarting; it can only terminate, stop, or continue a process. Our controller implements restart at the application level using `SIGTERM` + `fork()` + `exec()`.

---

## Q23. Why is `kill(pid, 0)` insufficient to establish process health?

**Answer:**  
`kill(pid, 0)` sends no signal but checks if the process exists and the caller has permission to signal it. It returns `0` if the process exists. However:
- A zombie process passes this check even though it is dead.
- A process may be in an infinite loop, deadlocked, or consuming 100% CPU and still "exist."
- A new, unrelated process may have been assigned the same PID (PID reuse).

Therefore, `kill(pid, 0)` only checks existence, not health or identity.

---

## Q24. How does logging help debugging?

**Answer:**  
Our timestamped log file (`logs/activity.log`) records:
- Every signal sent and to which PID.
- Worker launches and exits.
- Errors from system calls.
- Invalid input attempts.

This creates an audit trail. If the controller crashes or behaves unexpectedly, the log shows exactly what operations were performed and in what order — invaluable for post-mortem debugging.

---

## Q25. How does the application handle errors?

**Answer:**  
At multiple levels:
1. **Input validation**: `strtol()` with range and format checks; rejects empty, non-numeric, negative, zero, and overflow inputs.
2. **System-call error checking**: every call to `fork()`, `execl()`, `kill()`, `waitpid()`, `fopen()`, `mkdir()` is checked against its error return value.
3. **Permission errors**: `EPERM` from `kill()` is caught and reported clearly.
4. **Non-existent PIDs**: `/proc/<PID>` absence is detected before reading.
5. **Safety guards**: PID 1, negative PIDs, and the controller's own PID are rejected by `safe_kill()`.
6. **Timeout handling**: `pm_terminate_worker()` uses a bounded polling loop instead of blocking indefinitely.

---

## Q26. What are the project's limitations?

**Answer:**  
1. **TOCTOU race**: Checking a PID and then signalling it is not atomic — the process may exit between the two operations.
2. **No SIGKILL escalation**: The controller does not forcibly kill unresponsive processes.
3. **Single-threaded menu**: The menu blocks on user input; worker heartbeats appear between prompts.
4. **Only own children**: The controller cannot restart arbitrary external processes (only its own workers).
5. **No persistence**: If the controller exits unexpectedly, workers it launched are orphaned (reparented to init).

---

*End of VIVA preparation — 26 Questions and Answers*
