# Test Plan — Linux Signal-Based Process Controller

## Overview

This document describes both the **automated tests** (in `tests/run_tests.sh`) and the **manual test cases** for features that require interactive or visual verification.

---

## Part 1: Automated Tests (`make test`)

Run from the project root:

```bash
make clean && make && make test
```

| Test ID | Description | Method | Status |
|---------|-------------|--------|--------|
| T01 | Controller binary exists and is executable | `[[ -x build/controller ]]` | Automated |
| T02 | Worker binary exists and is executable | `[[ -x build/worker ]]` | Automated |
| T03 | Worker launches and gets a PID | `kill -0 $PID` | Automated |
| T04 | Worker output contains `PID=<number>` | grep pattern | Automated |
| T05 | Worker produces ≥2 heartbeats in 5 seconds | count grep matches | Automated |
| T06 | `SIGSTOP` sets `/proc` state to `T` | read `/proc/<PID>/stat` | Automated |
| T07 | `SIGCONT` returns state to `S` or `R` | read `/proc/<PID>/stat` | Automated |
| T08 | Worker exits within 3s after `SIGTERM` | timed polling loop | Automated |
| T09 | Worker is reaped (no zombie after `wait`) | check `/proc/<PID>` absence | Automated |
| T10 | `/proc/<PID>/stat` is readable | file open | Automated |
| T11 | Process name can be extracted from stat | sed between `(` and `)` | Automated |
| T12 | Log file is created after controller run | `[[ -f logs/activity.log ]]` | Automated |
| T13 | Log contains ISO-8601 timestamps | grep regex | Automated |
| T14 | Log contains startup/shutdown entries | grep string | Automated |
| T15 | Negative PID guard present in source | grep in source | Automated |
| T16 | PID 1 guard present in source | grep in source | Automated |
| T17 | Controller self-signal guard present | grep in source | Automated |
| T18 | Rebuild succeeds after `make clean` | make clean + make | Automated |
| T19 | Worker exits within 19ms of `SIGTERM` | timed poll | Automated |
| T20 | Two workers run simultaneously | `kill -0` both PIDs | Automated |
| T21 | Terminating one worker doesn't kill other | `kill -0` survivor | Automated |

**Actual result (executed on WSL2):** ✅ **23/23 PASSED**

---

## Part 2: Manual Test Cases

### MT-01: Menu Input Validation

**Steps:**
1. Launch `./build/controller`
2. Enter `abc` (non-numeric)
3. Enter `-5` (negative)
4. Enter `99` (out of range)
5. Enter empty string (just press Enter)

**Expected:**
- Each invalid input prints a clear error message.
- The menu re-displays without crashing.
- No panic, segfault, or undefined behaviour.

---

### MT-02: Invalid PID Input

**Steps:**
1. Choose option 3 (Pause)
2. Enter `0` as PID
3. Enter `-100` as PID
4. Enter `abc` as PID
5. Enter `9999999` (a PID that does not exist)

**Expected:**
- `0` and `-100` rejected: "PID must be a positive integer"
- `abc` rejected: "non-numeric characters found"
- `9999999` accepted as integer, then rejected: "not a managed worker" (option 3 only allows managed workers) or "does not exist" (option 7)

---

### MT-03: Pause and Verify via Second Terminal

**Steps:**
1. Launch controller, start a worker (option 1), note PID.
2. In a second terminal: `watch -n 0.5 'cat /proc/<PID>/stat | cut -d" " -f3'`
3. Choose option 3 in controller, enter PID.
4. Observe second terminal showing `T`.
5. Choose option 4, enter PID.
6. Observe second terminal showing `S`.

**Expected:**
- State changes from `S` → `T` after SIGSTOP.
- State changes from `T` → `S` after SIGCONT.
- Heartbeats stop during pause, resume after SIGCONT.

---

### MT-04: Graceful Termination Message

**Steps:**
1. Launch a worker (option 1).
2. Observe heartbeats.
3. Choose option 5, enter PID.

**Expected output from worker:**
```
  [WORKER] PID=XXXXX received SIGTERM — shutting down cleanly.
```

**Expected from controller:**
```
  [✓] PID XXXXX has exited.
```

---

### MT-05: Restart Shows Different PIDs

**Steps:**
1. Launch a worker. Note PID A.
2. Choose option 6 (Restart), enter PID A.
3. Observe output.

**Expected:**
```
  Old PID : A  (terminated and reaped)
  New PID : B  (running)
```
Where A ≠ B. Verify new PID is running: `ps -p B`.

---

### MT-06: Process Information for Non-Existent PID

**Steps:**
1. Choose option 7.
2. Enter a PID you know does not exist (e.g., 99998).

**Expected:**
```
  [!] Unable to retrieve info: PID 99998 does not exist (process has exited)
```

---

### MT-07: Log File Content Inspection

**Steps:**
1. Run the controller, perform: launch, pause, resume, terminate.
2. Choose option 8 (View Log) OR: `cat logs/activity.log`

**Expected log entries (in order):**
- `Controller started`
- `Worker launched: PID=...`
- `Signal sent: SIGSTOP -> PID ...`
- `Signal sent: SIGCONT -> PID ...`
- `Signal sent: SIGTERM -> PID ...`
- `Process PID ... exited normally with code 0`
- `Controller exiting normally`

---

### MT-08: Ctrl-C Shutdown

**Steps:**
1. Launch controller with a running worker.
2. Press Ctrl+C at the menu prompt.

**Expected:**
- Controller prints `[Signal received — shutting down]`
- Sends SIGTERM to all managed workers.
- Logs shutdown.
- Returns to shell prompt cleanly.

---

### MT-09: EOF Shutdown (Ctrl-D)

**Steps:**
1. Launch controller.
2. Press Ctrl+D at the menu prompt.

**Expected:**
- Controller prints `[EOF received — exiting.]`
- Cleans up workers.
- Returns to shell.

---

### MT-10: Termination Timeout (Process Ignoring SIGTERM)

> Note: This test requires manually building a worker variant that ignores SIGTERM.
> In the default worker, SIGTERM is always handled.

**Simulated steps (for documentation only):**
1. If a process ignores SIGTERM, the controller polls for `TERMINATE_TIMEOUT_SEC` (5 seconds).
2. After timeout, controller prints: `PID X did not exit within 5 seconds.`
3. The controller does NOT automatically send SIGKILL.

---

### MT-11: Permission-Denied Handling

**Steps (requires another user's process):**
1. Start a process as a different user: `su - otheruser -c 'sleep 1000 &'`
2. In controller, try option 7 (inspect) and option 5 (terminate) with that PID.

**Expected:**
- Option 7: Error message about permission denied.
- Option 5: Error "not a managed worker" (controller only manages its own children).

---

## Part 3: Build Verification Tests

| Step | Command | Expected Result |
|------|---------|----------------|
| Clean build | `make clean && make` | Zero errors, zero warnings |
| Binaries present | `ls -la build/` | `controller` and `worker` listed |
| Run `make clean` again | `make clean` | `build/` directory removed |
| Logs preserved | `ls logs/` | `activity.log` still present |
| Source intact | `ls src/` | All `.c` and `.h` files present |

---

## Known Limitations (Not Tested Automatically)

1. **SIGKILL escalation**: Not implemented by design.
2. **Arbitrary external PID control**: Not supported (only managed workers).
3. **Multi-user permission tests**: Require `su` or a second user account.
4. **Exact timing assertions**: Tests use bounded polling (100ms intervals) to avoid flakiness.
5. **Worker exec failure**: Would require a broken executable; not tested to avoid setup complexity.
