#!/usr/bin/env bash
# shellcheck disable=SC2004
# =============================================================================
# tests/run_tests.sh — Automated test suite for Linux Signal-Based Process
#                      Controller.
#
# Run with:   make test
#        or:  bash tests/run_tests.sh
#
# Tests are run from the project root directory.
# =============================================================================

set -euo pipefail

CTRL=./build/controller
WORKER=./build/worker
LOG=./logs/activity.log
PASS=0
FAIL=0
TOTAL=0

# --------------------------------------------------------------------------
# Colour helpers
# --------------------------------------------------------------------------
RED='\033[31m'
GRN='\033[32m'
YLW='\033[33m'
CYN='\033[36m'
RST='\033[0m'
BLD='\033[1m'

header() { echo -e "\n${CYN}${BLD}==[ $* ]==${RST}"; }
pass()   { echo -e "  ${GRN}[PASS]${RST} $*"; PASS=$((PASS+1)); TOTAL=$((TOTAL+1)); }
fail()   { echo -e "  ${RED}[FAIL]${RST} $*"; FAIL=$((FAIL+1)); TOTAL=$((TOTAL+1)); }
info()   { echo -e "  ${YLW}[INFO]${RST} $*"; }

# --------------------------------------------------------------------------
# Trap: clean up any workers we started
# --------------------------------------------------------------------------
declare -a WORKER_PIDS=()
cleanup() {
    for pid in "${WORKER_PIDS[@]:-}"; do
        if kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null || true
        fi
    done
    wait 2>/dev/null || true
}
trap cleanup EXIT

# --------------------------------------------------------------------------
# T01 — Binary existence check
# --------------------------------------------------------------------------
header "T01: Binary existence"

if [[ -x "$CTRL" ]]; then
    pass "Controller binary exists and is executable: $CTRL"
else
    fail "Controller binary missing or not executable: $CTRL"
fi

if [[ -x "$WORKER" ]]; then
    pass "Worker binary exists and is executable: $WORKER"
else
    fail "Worker binary missing or not executable: $WORKER"
fi

# --------------------------------------------------------------------------
# T02 — Worker launch (standalone)
# --------------------------------------------------------------------------
header "T02: Worker launch"

"$WORKER" &
W_PID=$!
WORKER_PIDS+=("$W_PID")
sleep 0.5

if kill -0 "$W_PID" 2>/dev/null; then
    pass "Worker started with PID $W_PID"
else
    fail "Worker did not start"
fi

# --------------------------------------------------------------------------
# T03 — Worker PID is displayed
# --------------------------------------------------------------------------
header "T03: Worker PID display"

TMP_OUT=$(mktemp)
"$WORKER" > "$TMP_OUT" 2>&1 &
W2=$!
WORKER_PIDS+=("$W2")
sleep 0.3

if grep -qE "PID=[[:space:]]*[0-9]+" "$TMP_OUT" 2>/dev/null; then
    pass "Worker output contains PID=<number>"
else
    fail "Worker output did not contain PID= pattern"
    info "Worker output was: $(cat "$TMP_OUT")"
fi
rm -f "$TMP_OUT"

# --------------------------------------------------------------------------
# T04 — Worker heartbeat output
# --------------------------------------------------------------------------
header "T04: Worker heartbeat"

TMP_HB=$(mktemp)
"$WORKER" > "$TMP_HB" 2>&1 &
W3=$!
WORKER_PIDS+=("$W3")
sleep 5   # allow at least two heartbeats (interval = 2s)

BEAT_COUNT=$(grep -c "beat=" "$TMP_HB" 2>/dev/null || echo 0)
if [[ "$BEAT_COUNT" -ge 2 ]]; then
    pass "Worker produced $BEAT_COUNT heartbeat line(s) in 5 seconds"
else
    fail "Expected ≥2 heartbeat lines; got $BEAT_COUNT"
    info "Worker output: $(cat "$TMP_HB")"
fi
rm -f "$TMP_HB"

# --------------------------------------------------------------------------
# T05 — Pause: SIGSTOP changes /proc state to T
# --------------------------------------------------------------------------
header "T05: Pause (SIGSTOP) state verification"

"$WORKER" &
W4=$!
WORKER_PIDS+=("$W4")
sleep 0.5

kill -STOP "$W4"
sleep 0.2

PROC_STATE=$(cat "/proc/$W4/stat" 2>/dev/null | awk '{print $3}' || echo "?")
if [[ "$PROC_STATE" == "T" ]]; then
    pass "Process $W4 is in state T (stopped) after SIGSTOP"
else
    fail "Expected state T; got '$PROC_STATE' for PID $W4"
fi

# --------------------------------------------------------------------------
# T06 — Resume: SIGCONT returns process to running/sleeping state
# --------------------------------------------------------------------------
header "T06: Resume (SIGCONT) state verification"

kill -CONT "$W4"
sleep 0.3

PROC_STATE2=$(cat "/proc/$W4/stat" 2>/dev/null | awk '{print $3}' || echo "?")
if [[ "$PROC_STATE2" == "S" || "$PROC_STATE2" == "R" ]]; then
    pass "Process $W4 resumed to state '$PROC_STATE2' after SIGCONT"
else
    fail "Expected S or R after SIGCONT; got '$PROC_STATE2'"
fi

# --------------------------------------------------------------------------
# T07 — Graceful termination via SIGTERM
# --------------------------------------------------------------------------
header "T07: Graceful termination (SIGTERM)"

"$WORKER" &
W5=$!
WORKER_PIDS+=("$W5")
sleep 0.5

kill -TERM "$W5"
for i in $(seq 1 50); do
    if ! kill -0 "$W5" 2>/dev/null; then
        break
    fi
    sleep 0.1
done

if ! kill -0 "$W5" 2>/dev/null; then
    pass "Worker PID $W5 exited after SIGTERM"
    wait "$W5" 2>/dev/null || true
else
    fail "Worker PID $W5 still running after SIGTERM"
fi

# --------------------------------------------------------------------------
# T08 — Zombie prevention: waitpid reaps children
# --------------------------------------------------------------------------
header "T08: Zombie prevention"

"$WORKER" &
W6=$!
WORKER_PIDS+=("$W6")
sleep 0.3

kill -TERM "$W6"
sleep 1
wait "$W6" 2>/dev/null || true

# After wait(), the PID should no longer appear in /proc.
if [[ ! -d "/proc/$W6" ]]; then
    pass "Worker PID $W6 was reaped (no /proc/$W6)"
else
    ZSTATE=$(cat "/proc/$W6/stat" 2>/dev/null | awk '{print $3}' || echo "?")
    if [[ "$ZSTATE" == "Z" ]]; then
        fail "Worker PID $W6 is a zombie (not reaped)"
    else
        info "PID $W6 still has /proc entry (state=$ZSTATE); may be brief race"
        pass "No zombie state observed for PID $W6"
    fi
fi

# --------------------------------------------------------------------------
# T09 — /proc/<pid>/stat parsing: name extraction
# --------------------------------------------------------------------------
header "T09: /proc stat parsing"

"$WORKER" &
W7=$!
WORKER_PIDS+=("$W7")
sleep 0.2

STAT_LINE=$(cat "/proc/$W7/stat" 2>/dev/null || echo "")
if [[ -n "$STAT_LINE" ]]; then
    pass "/proc/$W7/stat is readable"
    # Extract name between first '(' and last ')'
    NAME_RAW=$(echo "$STAT_LINE" | sed 's/.*(\(.*\)).*/\1/')
    if [[ -n "$NAME_RAW" ]]; then
        pass "Extracted process name: '$NAME_RAW'"
    else
        fail "Could not extract process name from stat line"
    fi
else
    fail "/proc/$W7/stat is not readable"
fi

kill -TERM "$W7" 2>/dev/null || true
wait "$W7" 2>/dev/null || true

# --------------------------------------------------------------------------
# T10 — Log file creation
# --------------------------------------------------------------------------
header "T10: Log file creation"

# Create the log dir and a quick log write by invoking the controller with
# immediate EOF (option 0 — exit).
mkdir -p logs

# We can't interactively drive the controller in a test; simulate by running
# the controller with piped input '0\n' (choose exit immediately).
printf '0\n' | timeout 5 "$CTRL" > /dev/null 2>&1 || true

if [[ -f "$LOG" ]]; then
    pass "Log file created: $LOG"
else
    fail "Log file not found at: $LOG"
fi

# --------------------------------------------------------------------------
# T11 — Log timestamps
# --------------------------------------------------------------------------
header "T11: Log timestamps"

if [[ -f "$LOG" ]]; then
    if grep -qE "\[20[0-9]{2}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\]" "$LOG"; then
        pass "Log contains ISO-8601 timestamps"
    else
        fail "Log does not contain expected timestamp format"
    fi
else
    fail "Log file not found; cannot check timestamps"
fi

# --------------------------------------------------------------------------
# T12 — Log contains startup/shutdown entries
# --------------------------------------------------------------------------
header "T12: Log startup and shutdown entries"

if [[ -f "$LOG" ]]; then
    if grep -q "Controller started" "$LOG"; then
        pass "Log contains 'Controller started' entry"
    else
        fail "Log missing 'Controller started'"
    fi
    if grep -q "Controller" "$LOG"; then
        pass "Log contains controller lifecycle entry"
    else
        fail "Log missing lifecycle entries"
    fi
else
    fail "Log file not found"
fi

# --------------------------------------------------------------------------
# T13 — Invalid PID handling (negative)
# --------------------------------------------------------------------------
header "T13: SIGTERM to negative PID rejected by safe_kill"

# Negative PIDs would signal process groups; our safe_kill() rejects pid<=0.
# Test by checking that kill -0 with a negative PID is not used in controller.
if grep -q "pid <= 0" src/process_manager.c 2>/dev/null; then
    pass "Source code rejects pid <= 0 in safe_kill()"
else
    fail "Could not verify negative PID guard in source"
fi

# --------------------------------------------------------------------------
# T14 — PID 1 protection
# --------------------------------------------------------------------------
header "T14: PID 1 protection"

if grep -q "pid == 1" src/process_manager.c 2>/dev/null; then
    pass "Source code explicitly refuses to signal PID 1"
else
    fail "Could not verify PID 1 guard in source"
fi

# --------------------------------------------------------------------------
# T15 — Controller self-signal protection
# --------------------------------------------------------------------------
header "T15: Controller self-signal protection"

if grep -q "getpid()" src/process_manager.c 2>/dev/null; then
    pass "Source code checks against controller's own PID"
else
    fail "Could not verify self-signal guard in source"
fi

# --------------------------------------------------------------------------
# T16 — Rebuild after make clean
# --------------------------------------------------------------------------
header "T16: Rebuild after make clean"

make clean > /dev/null 2>&1

if [[ -d "./build" ]] && ls ./build/*.o > /dev/null 2>&1; then
    fail "build/ directory still contains object files after make clean"
else
    pass "build/ directory cleaned successfully"
fi

make > /dev/null 2>&1
if [[ -x "$CTRL" && -x "$WORKER" ]]; then
    pass "Rebuild after clean succeeded"
else
    fail "Rebuild after clean failed"
fi

# --------------------------------------------------------------------------
# T17 — Worker responds to SIGTERM within 3 seconds
# --------------------------------------------------------------------------
header "T17: Worker SIGTERM response time"

"$WORKER" &
W8=$!
WORKER_PIDS+=("$W8")
sleep 0.5

START_NS=$(date +%s%N 2>/dev/null || echo 0)
kill -TERM "$W8"

EXITED=0
for i in $(seq 1 30); do
    if ! kill -0 "$W8" 2>/dev/null; then
        EXITED=1
        break
    fi
    sleep 0.1
done

if [[ "$EXITED" -eq 1 ]]; then
    END_NS=$(date +%s%N 2>/dev/null || echo 0)
    ELAPSED_MS=$(( (END_NS - START_NS) / 1000000 ))
    pass "Worker exited within ${ELAPSED_MS}ms after SIGTERM"
    wait "$W8" 2>/dev/null || true
else
    fail "Worker did not exit within 3s of SIGTERM"
fi

# --------------------------------------------------------------------------
# T18 — Multiple workers do not confuse each other
# --------------------------------------------------------------------------
header "T18: Multiple workers tracked independently"

"$WORKER" &
WA=$!
WORKER_PIDS+=("$WA")
"$WORKER" &
WB=$!
WORKER_PIDS+=("$WB")
sleep 0.5

if kill -0 "$WA" 2>/dev/null && kill -0 "$WB" 2>/dev/null; then
    pass "Two workers running simultaneously: PID $WA and PID $WB"
else
    fail "Failed to verify two simultaneous workers"
fi

# Terminate one; verify the other still runs.
kill -TERM "$WA"
for i in $(seq 1 30); do
    if ! kill -0 "$WA" 2>/dev/null; then break; fi
    sleep 0.1
done
wait "$WA" 2>/dev/null || true

if kill -0 "$WB" 2>/dev/null; then
    pass "Worker $WB still running after worker $WA was terminated"
else
    fail "Worker $WB unexpectedly exited"
fi

kill -TERM "$WB" 2>/dev/null || true
wait "$WB" 2>/dev/null || true

# --------------------------------------------------------------------------
# Summary
# --------------------------------------------------------------------------
echo ""
echo -e "${BLD}════════════════════════════════════════${RST}"
echo -e "${BLD}  TEST RESULTS${RST}"
echo -e "${BLD}════════════════════════════════════════${RST}"
echo -e "  Total : $TOTAL"
echo -e "  ${GRN}Passed: $PASS${RST}"
if [[ "$FAIL" -gt 0 ]]; then
    echo -e "  ${RED}Failed: $FAIL${RST}"
else
    echo -e "  ${GRN}Failed: 0${RST}"
fi
echo -e "${BLD}════════════════════════════════════════${RST}"
echo ""

[[ "$FAIL" -eq 0 ]]
