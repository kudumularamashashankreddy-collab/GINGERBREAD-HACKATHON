# DEMO.md — Five-Minute Presentation Script
# Linux Signal-Based Process Controller

---

## Presenter Notes

> Use this script for your lab viva or college project demonstration.  
> All commands shown here match the actual implementation.  
> Estimated time: **5 minutes**.

---

## Minute 0:00 – 0:45 | Project Introduction

**Say:**

> "Good morning. My project is called the **Linux Signal-Based Process Controller** — a terminal application written in C that demonstrates how the Linux kernel manages processes using signals.
>
> The project covers five core Operating Systems concepts:
> - Process creation using `fork()` and `exec()`
> - Signal dispatch using `kill()` with `SIGSTOP`, `SIGCONT`, and `SIGTERM`
> - Live process state inspection using the `/proc` virtual filesystem
> - Zombie prevention using `waitpid()`
> - Application-level process restart"

---

## Minute 0:45 – 1:15 | Architecture Overview

**Draw or show the architecture diagram from README.md, then say:**

> "The controller has four modules:
> 1. **Process Manager** — handles `fork`, `exec`, `kill`, `waitpid`
> 2. **Process Info** — reads `/proc/<PID>/stat` for live state
> 3. **Signal Handler** — installs async-safe handlers for controller signals
> 4. **Logger** — writes timestamped events to `logs/activity.log`
>
> Workers are separate executables launched as child processes."

---

## Minute 1:15 – 1:45 | Build

**Type in terminal:**

```bash
cd linux-signal-controller
make clean && make
```

**Point out:**
- GCC compiles with `-Wall -Wextra -Wpedantic` — zero warnings.
- Both `build/controller` and `build/worker` are produced.

> "The Makefile compiles five source modules into the controller and one module into the worker, all using GCC with strict warnings enabled."

---

## Minute 1:45 – 2:15 | Launch and Worker Creation

**Type:**

```bash
./build/controller
```

**At the menu, press `1` (Launch Worker):**

> "I press 1 to launch a worker. The controller calls `fork()` to create a child process, then `exec()` replaces the child's image with the worker binary. Notice the **new PID** printed — that's the kernel-assigned process identifier."

**In the worker output you will see:**
```
  [WORKER] Started  PID=12345
  [WORKER] I will print a heartbeat every 2 second(s).
  [WORKER] PID=12345   beat=1     10:20:05  ♥
```

**Open a second terminal and verify:**
```bash
ps -p 12345 -o pid,ppid,stat,comm
```

---

## Minute 2:15 – 2:45 | Pause and Resume

**At the menu, press `2` (List Managed Processes):**
> "Option 2 lists all tracked workers. It shows the logical state, the `/proc` state character, and the executable path."

**Press `3` (Pause Process), enter the PID:**
> "Option 3 sends `SIGSTOP`. Notice that `SIGSTOP` **cannot be caught or ignored** — the kernel suspends the process immediately. We verify by reading `/proc/<PID>/stat` and confirming state `T`."

**Verify in the second terminal:**
```bash
cat /proc/12345/stat | awk '{print $3}'
# Expected: T
```

> "Heartbeats stop appearing — the worker is frozen."

**Press `4` (Resume Process), enter the same PID:**
> "Option 4 sends `SIGCONT`. The process becomes eligible to run again. The kernel schedules it and heartbeats resume."

**Verify:**
```bash
cat /proc/12345/stat | awk '{print $3}'
# Expected: S (sleeping between heartbeats)
```

---

## Minute 2:45 – 3:15 | Graceful Termination

**Press `5` (Terminate Process), enter the PID:**

> "Option 5 sends `SIGTERM` — a polite termination request. Unlike `SIGKILL`, the process **can** catch this. Our worker's handler sets a flag; the heartbeat loop exits cleanly."

**Worker output:**
```
  [WORKER] PID=12345 received SIGTERM — shutting down cleanly.
```

**Controller output:**
```
  [✓] PID 12345 has exited.
```

> "The controller waits up to 5 seconds using `waitpid()` to confirm exit — this prevents zombie processes."

---

## Minute 3:15 – 3:50 | Restart with New PID

**Press `1` to launch a new worker, then press `6` (Restart Worker), enter the PID:**

> "Restart is **not a Linux signal** — it is an application-level operation. The controller:
> 1. Sends `SIGTERM` to the old worker and waits for it to exit.
> 2. Calls `fork()` + `exec()` to create a brand-new process.
>
> The old PID is gone; the new PID is different."

**Expected output:**
```
  [✓] Restart complete:
      Old PID : 12350 (terminated and reaped)
      New PID : 12367 (running)
```

> "This is how service managers like `systemd` implement service restart."

---

## Minute 3:50 – 4:20 | Process Information

**Press `7` (View Process Information), enter any running PID:**

> "Option 7 reads `/proc/<PID>/stat` directly. We parse the process name between the parentheses — carefully, because the name may contain spaces and parentheses."

**Expected output:**
```
  ┌──────────────────────────────────────────────┐
  │  PID   : 12367                               │
  │  Name  : worker                              │
  │  State : S  Sleeping (interruptible…)        │
  └──────────────────────────────────────────────┘
```

---

## Minute 4:20 – 4:45 | Activity Log

**Press `8` (View Activity Log):**

> "Every operation is recorded in `logs/activity.log` with an ISO-8601 timestamp. This is essential for debugging — if something goes wrong, the log shows exactly what signals were sent and when."

**Or in the second terminal:**
```bash
cat logs/activity.log
```

---

## Minute 4:45 – 5:00 | Conclusion and Concepts Learned

**Press `0` (Exit):**

> "Before I close — the OS concepts this project demonstrates:
>
> 1. **`fork()` + `exec()`** — standard UNIX process creation
> 2. **`SIGSTOP`** — kernel-enforced suspend (cannot be caught)
> 3. **`SIGCONT`** — resume suspended process
> 4. **`SIGTERM`** — polite, catchable termination request
> 5. **`waitpid()`** — reaping children, preventing zombies
> 6. **`/proc` filesystem** — kernel's live process data interface
> 7. **Async-signal-safe handlers** — using volatile flags, not library calls
> 8. **Application-level restart** — terminate + re-fork, not a kernel feature
>
> Thank you."

---

## Safe Cleanup Commands

Run these after the demo to ensure no stray workers remain:

```bash
# List any leftover worker processes
pgrep -a worker

# If any remain, send SIGTERM
pkill -TERM worker

# Verify none remain
pgrep worker && echo "Still running" || echo "All cleaned up"
```

---

## Screenshot Checklist

Capture the following screenshots for your report:

| # | Screenshot | How to capture |
|---|---|---|
| 1 | Project structure in VS Code | Open folder in VS Code, screenshot Explorer panel |
| 2 | Successful `make` build output | Run `make clean && make` in terminal |
| 3 | Main application menu | Launch `./build/controller` |
| 4 | Worker heartbeat output | After option 1, wait 6+ seconds |
| 5 | Worker in stopped state (state T) | After option 3; run `cat /proc/<PID>/stat` |
| 6 | Worker after resume | After option 4; heartbeats resume |
| 7 | Termination confirmation | After option 5 |
| 8 | Restart showing old+new PID | After option 6 |
| 9 | Process information panel | After option 7 |
| 10 | Activity log contents | After option 8, or `cat logs/activity.log` |
| 11 | Test suite results (23/23 pass) | Run `make test` |

> **Note**: All screenshots must be captured manually on a running Ubuntu/WSL2 system.  
> PIDs will differ between runs — this is expected and correct.
