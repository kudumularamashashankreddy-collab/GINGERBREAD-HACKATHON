# Linux Signal-Based Process Controller

## Abstract

A terminal-based C application for Ubuntu/Linux that demonstrates core operating system concepts — process creation, lifecycle management, and inter-process communication via POSIX signals. The controller uses `fork()`, `exec()`, `kill()`, and `waitpid()` to manage child worker processes, reading `/proc/<PID>/stat` for real-time process state information and maintaining a timestamped activity log.

---

## Problem Statement

Second-year B.Tech CSE students learn about Linux processes and signals theoretically but rarely interact with them at the system-call level. This project bridges that gap by building a working controller that creates, pauses, resumes, terminates, and restarts worker processes using the same system calls used by production tools like shells and service managers.

---

## Objectives

1. Demonstrate POSIX process creation with `fork()` and `exec()`.
2. Implement signal dispatch (`SIGSTOP`, `SIGCONT`, `SIGTERM`) via `kill()`.
3. Prevent zombie processes with `waitpid()`.
4. Read the Linux `/proc` virtual filesystem for live process state.
5. Implement an application-level restart (terminate + re-fork) and explain why restart is not a Linux signal.
6. Handle all user input errors and system-call failures gracefully.
7. Maintain a timestamped activity log.

---

## Features

| Menu Option | Feature | Signal / Call |
|---|---|---|
| 1 | Launch Worker | `fork()` + `execl()` |
| 2 | List Managed Processes | `/proc/<PID>/stat` |
| 3 | Pause Process | `kill(pid, SIGSTOP)` |
| 4 | Resume Process | `kill(pid, SIGCONT)` |
| 5 | Terminate Process | `kill(pid, SIGTERM)` + `waitpid()` |
| 6 | Restart Worker | Terminate + re-fork/exec |
| 7 | View Process Information | `/proc/<PID>/stat` |
| 8 | View Activity Log | `logs/activity.log` |
| 9 | Help | Inline explanations |

---

## Technologies Used

| Technology | Version | Purpose |
|---|---|---|
| Ubuntu Linux | 22.04+ / WSL2 | Execution environment |
| GCC | 12+ | C compiler |
| GNU Make | 4.3+ | Build system |
| C11 | ISO/IEC 9899:2011 | Language standard |
| POSIX.1-2008 | `_POSIX_C_SOURCE=200809L` | System-call API |
| `/proc` filesystem | Linux kernel | Live process data |

---

## System Requirements

- **OS**: Ubuntu 20.04+ or WSL2 (Windows 10/11)
- **Compiler**: GCC ≥ 9.0
- **Build tool**: GNU Make ≥ 4.0
- **Shell**: bash (for test script)
- **Packages**: `build-essential` (includes gcc + make)

```bash
sudo apt update && sudo apt install build-essential -y
```

---

## Architecture Diagram

```
  User
    │
    ▼
┌──────────────────────────────────────────────────────────┐
│             Interactive C Menu  (src/main.c)              │
│  Input validation · Menu loop · Signal-flag polling       │
└──────────────┬───────────────────────────────────────────┘
               │
       ┌───────┴────────┐
       ▼                ▼
┌─────────────┐   ┌────────────────┐
│ Process Mgr │   │ Process Info   │
│ (process_   │   │ (process_      │
│  manager.c) │   │  info.c)       │
│             │   │                │
│ fork()+exec │   │ /proc/<pid>/   │
│ kill()      │   │    stat        │
│ waitpid()   │   │                │
└──────┬──────┘   └────────────────┘
       │
       │──────────────────────────────┐
       ▼                              ▼
┌─────────────────┐       ┌──────────────────────┐
│ Signal Handler  │       │ Logger (logger.c)     │
│ (signal_        │       │                       │
│  handler.c)     │       │ logs/activity.log     │
│                 │       │ ISO-8601 timestamps   │
│ SIGINT/SIGTERM →│       └──────────────────────┘
│  g_shutdown flag│
│ SIGCHLD →       │
│  g_child_exited │
└─────────────────┘
       │
       ▼
┌──────────────────────────────────┐
│    Managed Worker Processes      │
│    (worker/worker.c)             │
│                                  │
│  Heartbeat every 2s              │
│  Handles SIGTERM cleanly         │
│  SIGSTOP / SIGCONT: kernel-only  │
└──────────────────────────────────┘
```

---

## Folder Structure

```
linux-signal-controller/
├── src/
│   ├── main.c              ← Menu loop and input handling
│   ├── process_manager.c   ← fork/exec/kill/waitpid logic
│   ├── process_manager.h
│   ├── signal_handler.c    ← Controller-side signal handlers
│   ├── signal_handler.h
│   ├── process_info.c      ← /proc/<PID>/stat reader
│   ├── process_info.h
│   ├── logger.c            ← Timestamped file logger
│   └── logger.h
├── worker/
│   └── worker.c            ← Heartbeat worker process
├── build/                  ← Compiled binaries (auto-created)
│   ├── controller
│   └── worker
├── logs/
│   ├── .gitkeep
│   └── activity.log        ← Written at runtime
├── tests/
│   ├── run_tests.sh        ← Automated test suite
│   └── test_plan.md        ← Manual test plan
├── Makefile
├── README.md
├── VIVA.md
├── DEMO.md
└── .gitignore
```

---

## Linux Process and Signal Concepts

### What is a Process?

A process is a running instance of a program. The Linux kernel gives each process:
- A unique **PID** (Process ID).
- Its own virtual address space (code, stack, heap).
- Open file descriptors.
- A parent PID (PPID).

### What is a Signal?

A signal is a software interrupt delivered asynchronously to a process. Common signals:

| Signal | Number | Catchable? | Default Action |
|---|---|---|---|
| `SIGTERM` | 15 | **Yes** | Terminate (gracefully) |
| `SIGKILL` | 9 | **No** | Terminate immediately |
| `SIGSTOP` | 19 | **No** | Suspend process |
| `SIGCONT` | 18 | Yes | Resume stopped process |
| `SIGCHLD` | 17 | Yes | Child state changed |
| `SIGINT`  | 2  | Yes | Keyboard interrupt |

### Process States (`/proc/<PID>/stat` field 3)

| State | Meaning |
|---|---|
| `R` | Running or runnable |
| `S` | Sleeping (interruptible) |
| `D` | Uninterruptible sleep (I/O) |
| `T` | Stopped by signal |
| `Z` | Zombie (exited, not reaped) |

---

## Important System Calls

### `fork()`
Creates a child process. Returns:
- `0` in the child.
- Child PID in the parent.
- `-1` on error.

### `exec()` family (`execl`, `execvp`, …)
Replaces the current process image with a new program. Does not return on success. Combined with `fork()`, this is the standard POSIX way to spawn a new program.

### `kill(pid, sig)`
Sends signal `sig` to process `pid`. Despite its name, it works for any signal. Returns `0` if the signal was sent (not necessarily received).

### `waitpid(pid, &status, flags)`
Waits for a specific child to change state. With `WNOHANG`, returns immediately if the child has not exited. Essential to reap zombies.

### `sigaction(sig, &act, NULL)`
Installs a signal handler. More portable and precise than `signal()`. The `sa_flags` field controls behaviour (e.g., `SA_RESTART` to restart interrupted syscalls).

---

## Build Instructions

```bash
# Clone or open the project directory
cd linux-signal-controller

# Build both controller and worker
make

# Clean build artefacts
make clean

# Rebuild
make clean && make
```

All binaries land in `build/`:
- `build/controller` — the interactive menu application
- `build/worker`     — the heartbeat worker (launched by the controller)

---

## Execution Instructions

```bash
make run
# or directly:
./build/controller
```

The controller must be run from the **project root directory** so that `build/worker` can be found at its relative path.

---

## Menu Usage Examples

```
Enter your choice: 1
  [Launch Worker]
  [✓] Worker launched with PID 12345
      The worker prints a heartbeat every 2 seconds.

Enter your choice: 2
  [Managed Processes]
  PID       Logical State   /proc State  Executable
  --------  --------------  ----------   ----------
  12345     RUNNING         S            build/worker

Enter your choice: 3
  [Pause Process — SIGSTOP]
  Enter PID to pause: 12345
  Sending SIGSTOP to PID 12345 ...
  Note: SIGSTOP cannot be caught, blocked, or ignored by the target.
  [✓] PID 12345 confirmed STOPPED (/proc state: T)

Enter your choice: 4
  [Resume Process — SIGCONT]
  Enter PID to resume: 12345
  Sending SIGCONT to PID 12345 ...
  [✓] PID 12345 resumed (/proc state: S)

Enter your choice: 5
  [Terminate Process — SIGTERM]
  Enter PID to terminate: 12345
  Sending SIGTERM to PID 12345 ...
  [✓] PID 12345 has exited.
```

---

## Testing Instructions

```bash
# Run automated test suite
make test

# Manual tests: see tests/test_plan.md
```

---

## Sample Expected Output (Illustrative)

```
  ╔══════════════════════════════════════════════════════╗
  ║     LINUX SIGNAL-BASED PROCESS CONTROLLER  v1.0     ║
  ║         OS Project — B.Tech CSE (2nd Year)          ║
  ╚══════════════════════════════════════════════════════╝

  [WORKER] Started  PID=13421
  [WORKER] I will print a heartbeat every 2 second(s).
  [WORKER] PID=13421   beat=1     14:32:07  ♥
  [WORKER] PID=13421   beat=2     14:32:09  ♥
  ...
  [WORKER] PID=13421 received SIGTERM — shutting down cleanly.
```

> **Note**: PIDs shown above are illustrative. Actual PIDs are assigned by the kernel at runtime.

---

## Logging Details

- **Log file**: `logs/activity.log`
- **Created**: automatically at controller startup
- **Format**: `[YYYY-MM-DD HH:MM:SS] event description`
- **Events logged**: startup, shutdown, worker launch, signals sent, process exits, errors, validation failures

Example log entries:
```
[2025-01-15 14:32:00] Controller started (PID 12100)
[2025-01-15 14:32:05] Worker launched: PID=12345  exe='build/worker'
[2025-01-15 14:32:12] Signal sent: SIGSTOP -> PID 12345
[2025-01-15 14:32:18] Signal sent: SIGCONT -> PID 12345
[2025-01-15 14:32:25] Signal sent: SIGTERM -> PID 12345
[2025-01-15 14:32:25] Process PID 12345 exited normally with code 0
[2025-01-15 14:32:30] Controller exiting normally
```

---

## Limitations and Safety Considerations

1. **TOCTOU race**: Checking a PID and then signalling it is not atomic. The kernel may reuse the PID between check and signal if the process exits in between. This controller mitigates it by tracking child lifecycle and refusing to signal reaped PIDs.

2. **No SIGKILL escalation**: If `SIGTERM` is ignored, the controller reports failure but does **not** automatically send `SIGKILL`. This is a safety decision — forceful kills can leave data in an inconsistent state.

3. **Only managed workers**: Pause/resume/terminate only work for workers launched by this controller. Arbitrary external processes are not managed.

4. **No privilege escalation**: The controller never uses `sudo`. It cannot signal processes owned by other users.

5. **WSL2 limitations**: On WSL2, some `/proc` fields and signal behaviours match native Linux but there can be subtle differences. All features tested on WSL2 Ubuntu behave correctly for this project.

6. **Single-threaded**: The controller is single-threaded. The menu blocks while waiting for input; heartbeat output from workers appears between menu prompts.

---

## Future Enhancements

- Support CPU/memory usage display from `/proc/<PID>/status`.
- Add a daemon mode that monitors workers and auto-restarts them.
- Support `SIGKILL` escalation as an explicit user option.
- Multi-worker selection (pause/resume all at once).
- A real-time dashboard using ncurses.
- Support for custom worker command-line arguments.
- Integration with `cgroups` for resource limiting.

---

## Conclusion

This project implements a complete, working Linux process controller that demonstrates:
- `fork()` + `exec()` for process creation.
- `SIGSTOP` / `SIGCONT` / `SIGTERM` signal dispatch.
- `/proc` filesystem interrogation.
- `waitpid()` for zombie prevention.
- Application-level restart semantics.
- Async-signal-safe handler design.
- Robust input validation and error handling.

It covers a significant portion of the Linux process management API that is fundamental to operating systems design.
