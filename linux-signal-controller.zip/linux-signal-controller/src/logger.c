/*
 * logger.c — Timestamped activity logger implementation
 *
 * Creates logs/activity.log, writing ISO-8601 timestamps before each entry.
 * Thread-safety is not required; single-threaded application.
 */

#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include "logger.h"

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>

static FILE *g_log_fp = NULL;

/* ------------------------------------------------------------------------ */
/* Internal helpers                                                           */
/* ------------------------------------------------------------------------ */

/* Write current ISO-8601 local timestamp to fp, e.g. "[2025-01-15 14:32:07] " */
static void write_timestamp(FILE *fp)
{
    time_t     now  = time(NULL);
    struct tm  tm_info;
    char       buf[32];

    if (localtime_r(&now, &tm_info) == NULL) {
        fputs("[TIMESTAMP-ERROR] ", fp);
        return;
    }
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tm_info);
    fprintf(fp, "[%s] ", buf);
}

/* Ensure the log directory exists; create it if absent. */
static int ensure_log_dir(void)
{
    struct stat st;
    if (stat(LOG_DIR, &st) == 0) {
        if (S_ISDIR(st.st_mode))
            return 0;          /* already a directory */
        fprintf(stderr, "logger: '%s' exists but is not a directory\n", LOG_DIR);
        return -1;
    }
    /* Try to create the directory (mode 0755). */
    if (mkdir(LOG_DIR, 0755) != 0) {
        fprintf(stderr, "logger: cannot create directory '%s': %s\n",
                LOG_DIR, strerror(errno));
        return -1;
    }
    return 0;
}

/* ------------------------------------------------------------------------ */
/* Public API                                                                 */
/* ------------------------------------------------------------------------ */

int log_init(void)
{
    if (ensure_log_dir() != 0)
        return -1;

    g_log_fp = fopen(LOG_FILE, "a");
    if (g_log_fp == NULL) {
        fprintf(stderr, "logger: cannot open '%s': %s\n",
                LOG_FILE, strerror(errno));
        return -1;
    }

    /* Disable buffering so entries are written immediately on crash/SIGKILL. */
    setvbuf(g_log_fp, NULL, _IONBF, 0);

    /* Write startup banner. */
    write_timestamp(g_log_fp);
    fprintf(g_log_fp,
            "============================================================\n");
    write_timestamp(g_log_fp);
    fprintf(g_log_fp,
            "Controller started (PID %d)\n", (int)getpid());

    return 0;
}

void log_close(void)
{
    if (g_log_fp == NULL)
        return;

    write_timestamp(g_log_fp);
    fprintf(g_log_fp, "Controller shutting down (PID %d)\n", (int)getpid());
    write_timestamp(g_log_fp);
    fprintf(g_log_fp,
            "============================================================\n");

    fclose(g_log_fp);
    g_log_fp = NULL;
}

void log_event(const char *fmt, ...)
{
    if (g_log_fp == NULL)
        return;

    write_timestamp(g_log_fp);

    va_list ap;
    va_start(ap, fmt);
    vfprintf(g_log_fp, fmt, ap);
    va_end(ap);

    /* Ensure each entry ends with a newline. */
    fputc('\n', g_log_fp);
}

void log_worker_launch(pid_t pid, const char *path)
{
    log_event("Worker launched: PID=%d  exe='%s'", (int)pid, path);
}

void log_signal_sent(const char *signal_name, pid_t target_pid)
{
    log_event("Signal sent: %s -> PID %d", signal_name, (int)target_pid);
}

void log_process_exit(pid_t pid, int status)
{
    if (WIFEXITED(status))
        log_event("Process PID %d exited normally with code %d",
                  (int)pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        log_event("Process PID %d killed by signal %d (%s)",
                  (int)pid, WTERMSIG(status),
                  strsignal(WTERMSIG(status)));
    else
        log_event("Process PID %d changed state (raw status 0x%x)",
                  (int)pid, (unsigned)status);
}
