/*
 * signal_handler.h — Controller-side signal handling for Linux Signal-Based
 *                    Process Controller.
 *
 * IMPORTANT DISTINCTION:
 *   This module deals with signals received BY the controller process itself
 *   (e.g. SIGINT from Ctrl-C, SIGCHLD from child state changes).
 *
 *   Signals SENT to managed worker processes (SIGSTOP, SIGCONT, SIGTERM) are
 *   dispatched by process_manager.c using kill(2).
 *
 * ASYNC-SIGNAL-SAFETY:
 *   POSIX restricts what may be called from a signal handler.  The handlers
 *   installed here only set volatile sig_atomic_t flags; all real work is
 *   done in the main loop once the flag is observed.
 *
 * WHY SIGSTOP AND SIGKILL CANNOT BE CAUGHT:
 *   SIGSTOP and SIGKILL are enforced directly by the Linux kernel and are
 *   never delivered to a user-space handler.  Any attempt to install a
 *   handler for them with sigaction() is silently ignored (or returns EINVAL).
 */

#ifndef SIGNAL_HANDLER_H
#define SIGNAL_HANDLER_H

#include <signal.h>

/*
 * g_shutdown_requested
 *   Set to 1 by the SIGINT/SIGTERM handler received by the CONTROLLER.
 *   The main loop checks this flag after each menu iteration and exits cleanly.
 */
extern volatile sig_atomic_t g_shutdown_requested;

/*
 * g_child_exited
 *   Set to 1 by the SIGCHLD handler whenever a child changes state.
 *   The main loop calls reap_children() when this flag is observed.
 */
extern volatile sig_atomic_t g_child_exited;

/*
 * signals_init()
 *   Install all controller-side signal handlers.
 *   Must be called once from main() before entering the menu loop.
 *   Returns 0 on success, -1 on failure.
 */
int signals_init(void);

#endif /* SIGNAL_HANDLER_H */
