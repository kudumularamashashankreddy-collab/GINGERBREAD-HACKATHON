/*
 * main.c — Linux Signal-Based Process Controller
 *
 * Entry point and interactive menu driver.
 *
 * Menu:
 *   1. Launch Worker
 *   2. List Managed Processes
 *   3. Pause Process
 *   4. Resume Process
 *   5. Terminate Process
 *   6. Restart Worker
 *   7. View Process Information
 *   8. View Recent Activity Log
 *   9. Show Help
 *   0. Exit
 */

#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <limits.h>

#include "process_manager.h"
#include "process_info.h"
#include "signal_handler.h"
#include "logger.h"

/* ------------------------------------------------------------------ */
/* Console helpers                                                       */
/* ------------------------------------------------------------------ */

#define CLR_RESET   "\033[0m"
#define CLR_BOLD    "\033[1m"
#define CLR_CYAN    "\033[36m"
#define CLR_GREEN   "\033[32m"
#define CLR_YELLOW  "\033[33m"
#define CLR_RED     "\033[31m"
#define CLR_MAGENTA "\033[35m"
#define CLR_BLUE    "\033[34m"

static void print_banner(void)
{
    printf(CLR_CYAN CLR_BOLD);
    printf("\n");
    printf("  ╔══════════════════════════════════════════════════════╗\n");
    printf("  ║     LINUX SIGNAL-BASED PROCESS CONTROLLER  v1.0     ║\n");
    printf("  ║         OS Project — B.Tech CSE (2nd Year)          ║\n");
    printf("  ╚══════════════════════════════════════════════════════╝\n");
    printf(CLR_RESET "\n");
}

static void print_menu(void)
{
    printf(CLR_BOLD "  ┌─────────────────────────────────────────────────────┐\n" CLR_RESET);
    printf(CLR_BOLD "  │                      MAIN MENU                     │\n" CLR_RESET);
    printf(CLR_BOLD "  ├─────────────────────────────────────────────────────┤\n" CLR_RESET);
    printf("  │  " CLR_GREEN "1" CLR_RESET ". Launch Worker                                    │\n");
    printf("  │  " CLR_GREEN "2" CLR_RESET ". List Managed Processes                           │\n");
    printf("  │  " CLR_YELLOW "3" CLR_RESET ". Pause Process (SIGSTOP)                         │\n");
    printf("  │  " CLR_GREEN "4" CLR_RESET ". Resume Process (SIGCONT)                        │\n");
    printf("  │  " CLR_RED "5" CLR_RESET ". Terminate Process (SIGTERM)                     │\n");
    printf("  │  " CLR_MAGENTA "6" CLR_RESET ". Restart Worker                                   │\n");
    printf("  │  " CLR_BLUE "7" CLR_RESET ". View Process Information (/proc)                │\n");
    printf("  │  " CLR_CYAN "8" CLR_RESET ". View Recent Activity Log                        │\n");
    printf("  │  " CLR_BOLD "9" CLR_RESET ". Show Help                                       │\n");
    printf("  │  " CLR_RED "0" CLR_RESET ". Exit                                            │\n");
    printf(CLR_BOLD "  └─────────────────────────────────────────────────────┘\n" CLR_RESET);
    printf("\n");
}

static void print_help(void)
{
    printf(CLR_BOLD CLR_CYAN "\n  === HELP ===\n" CLR_RESET);
    printf("\n");
    printf("  LINUX SIGNAL CONCEPTS:\n");
    printf("  ─────────────────────\n");
    printf("  SIGSTOP  : Suspends a process unconditionally.\n");
    printf("             Cannot be caught, blocked, or ignored by the target.\n");
    printf("             The kernel halts the process immediately.\n\n");
    printf("  SIGCONT  : Resumes a SIGSTOP'd process.\n");
    printf("             Makes the process eligible to run; the CPU scheduler\n");
    printf("             decides the actual execution time.\n\n");
    printf("  SIGTERM  : Polite termination request.\n");
    printf("             CAN be caught or ignored by the process.\n");
    printf("             Well-written programs perform cleanup then exit.\n\n");
    printf("  SIGKILL  : Forceful termination — NOT used automatically here.\n");
    printf("             Like SIGSTOP, it cannot be caught or ignored.\n\n");
    printf("  RESTART  : Not a Linux signal — it is an application-level\n");
    printf("             operation: terminate old process + fork/exec new one.\n");
    printf("             The new process gets a completely new PID.\n\n");
    printf("  PROCESS STATES (/proc/<PID>/stat field 3):\n");
    printf("  ──────────────────────────────────────────\n");
    printf("   R  Running or runnable (on CPU or ready queue)\n");
    printf("   S  Sleeping (waiting for event, interruptible)\n");
    printf("   D  Disk sleep (uninterruptible, usually I/O)\n");
    printf("   T  Stopped by signal (SIGSTOP / SIGTSTP)\n");
    printf("   Z  Zombie (exited, parent has not called wait() yet)\n\n");
    printf("  SAFETY RULES:\n");
    printf("  ─────────────\n");
    printf("   • This controller only signals workers it launched.\n");
    printf("   • PID 1 (init/systemd) is never signalled.\n");
    printf("   • The controller never signals itself.\n");
    printf("   • SIGKILL is NOT automatically escalated after SIGTERM.\n\n");
}

/* ------------------------------------------------------------------ */
/* Input utilities                                                       */
/* ------------------------------------------------------------------ */

/*
 * read_line()
 *   Read a line from stdin into buf (size bytes).
 *   Returns 1 on success, 0 on EOF or error.
 *   Strips the trailing newline.
 *   Discards excess input to prevent buffer overflow.
 */
static int read_line(char *buf, size_t size)
{
    if (fgets(buf, (int)size, stdin) == NULL)
        return 0;

    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        /* Input was longer than buf; discard remainder. */
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF)
            ;
    }
    return 1;
}

/*
 * parse_int_input()
 *   Parse buf as a decimal integer into *out.
 *   Rejects empty strings, non-numeric input, negative values, and overflow.
 *   Returns 1 on success, 0 on failure.
 */
static int parse_int_input(const char *buf, int *out)
{
    if (buf == NULL || buf[0] == '\0') {
        printf("  [!] Empty input.\n");
        return 0;
    }
    /* Allow leading whitespace. */
    while (isspace((unsigned char)*buf))
        buf++;
    if (*buf == '\0') {
        printf("  [!] Empty input after stripping whitespace.\n");
        return 0;
    }

    char *endp;
    errno = 0;
    long val = strtol(buf, &endp, 10);

    /* Check that the entire string was consumed. */
    while (isspace((unsigned char)*endp))
        endp++;
    if (*endp != '\0') {
        printf("  [!] Invalid input '%s': non-numeric characters found.\n", buf);
        return 0;
    }
    if (errno == ERANGE || val > INT_MAX || val < INT_MIN) {
        printf("  [!] Value out of range.\n");
        return 0;
    }
    *out = (int)val;
    return 1;
}

/*
 * prompt_pid()
 *   Display a prompt and read a PID.
 *   Rejects zero, negative, and excessively large values.
 *   Returns the PID on success, -1 on failure.
 */
static pid_t prompt_pid(const char *prompt)
{
    char buf[32];
    printf("  %s", prompt);
    fflush(stdout);
    if (!read_line(buf, sizeof(buf)))
        return -1;

    int val;
    if (!parse_int_input(buf, &val))
        return -1;
    if (val <= 0) {
        printf("  [!] PID must be a positive integer (got %d).\n", val);
        return -1;
    }
    return (pid_t)val;
}

/* ------------------------------------------------------------------ */
/* Menu action handlers                                                 */
/* ------------------------------------------------------------------ */

static void do_launch_worker(void)
{
    printf("\n" CLR_GREEN "  [Launch Worker]" CLR_RESET "\n");
    pid_t pid = pm_launch_worker(WORKER_EXE);
    if (pid > 0) {
        printf("  [✓] Worker launched with PID %d\n", (int)pid);
        printf("      The worker prints a heartbeat every 2 seconds.\n");
        printf("      It will exit cleanly on SIGTERM.\n");
    }
    printf("\n");
}

static void do_list_workers(void)
{
    printf("\n" CLR_BOLD "  [Managed Processes]" CLR_RESET "\n\n");
    pm_list_workers();
    printf("\n");
}

static void do_pause_worker(void)
{
    printf("\n" CLR_YELLOW "  [Pause Process — SIGSTOP]" CLR_RESET "\n");
    pid_t pid = prompt_pid("Enter PID to pause: ");
    if (pid > 0) {
        pm_pause_worker(pid);
    }
    printf("\n");
}

static void do_resume_worker(void)
{
    printf("\n" CLR_GREEN "  [Resume Process — SIGCONT]" CLR_RESET "\n");
    pid_t pid = prompt_pid("Enter PID to resume: ");
    if (pid > 0) {
        pm_resume_worker(pid);
    }
    printf("\n");
}

static void do_terminate_worker(void)
{
    printf("\n" CLR_RED "  [Terminate Process — SIGTERM]" CLR_RESET "\n");
    pid_t pid = prompt_pid("Enter PID to terminate: ");
    if (pid > 0) {
        pm_terminate_worker(pid);
    }
    printf("\n");
}

static void do_restart_worker(void)
{
    printf("\n" CLR_MAGENTA "  [Restart Worker]" CLR_RESET "\n");
    pid_t pid = prompt_pid("Enter PID of worker to restart: ");
    if (pid > 0) {
        pm_restart_worker(pid);
    }
    printf("\n");
}

static void do_process_info(void)
{
    printf("\n" CLR_BLUE "  [Process Information — /proc]" CLR_RESET "\n");
    pid_t pid = prompt_pid("Enter PID to inspect: ");
    if (pid <= 0)
        return;

    ProcessInfo info;
    get_process_info(pid, &info);
    printf("\n");
    print_process_info(&info);
    log_event("INSPECT: PID %d  valid=%d  state='%c'  name='%s'",
              (int)pid, info.valid, info.valid ? info.state : '?',
              info.valid ? info.name : "N/A");
    printf("\n");
}

static void do_view_log(void)
{
    printf("\n" CLR_CYAN "  [Recent Activity Log — %s]" CLR_RESET "\n\n", LOG_FILE);

    FILE *fp = fopen(LOG_FILE, "r");
    if (fp == NULL) {
        if (errno == ENOENT)
            printf("  Log file does not exist yet.\n");
        else
            printf("  Cannot open log: %s\n", strerror(errno));
        printf("\n");
        return;
    }

    /* Show last 30 lines. */
    #define MAX_LINES 30
    char *lines[MAX_LINES];
    int   count = 0;
    char  buf[512];

    while (fgets(buf, sizeof(buf), fp) != NULL) {
        char *copy = strdup(buf);
        if (copy == NULL) break;
        if (count < MAX_LINES) {
            lines[count++] = copy;
        } else {
            free(lines[0]);
            memmove(lines, lines + 1, (MAX_LINES - 1) * sizeof(char *));
            lines[MAX_LINES - 1] = copy;
        }
    }
    fclose(fp);

    for (int i = 0; i < count; i++) {
        printf("  %s", lines[i]);
        free(lines[i]);
    }
    printf("\n");
    #undef MAX_LINES
}

/* ------------------------------------------------------------------ */
/* Main                                                                  */
/* ------------------------------------------------------------------ */

int main(void)
{
    /* Initialise subsystems. */
    if (signals_init() != 0) {
        fprintf(stderr, "Fatal: failed to install signal handlers\n");
        return EXIT_FAILURE;
    }

    pm_init();

    if (log_init() != 0) {
        fprintf(stderr, "Warning: logging unavailable\n");
    }
    log_event("Menu loop starting (controller PID %d)", (int)getpid());

    print_banner();

    char input[16];
    int  choice;

    while (!g_shutdown_requested) {
        /* Reap any children that exited since last iteration. */
        if (g_child_exited) {
            g_child_exited = 0;
            pm_reap_children();
        }

        print_menu();
        printf("  Enter your choice: ");
        fflush(stdout);

        if (!read_line(input, sizeof(input))) {
            /* EOF (Ctrl-D) — treat as exit. */
            printf("\n  [EOF received — exiting.]\n");
            break;
        }

        if (!parse_int_input(input, &choice)) {
            log_event("Invalid menu input: '%s'", input);
            printf("  Please enter a number between 0 and 9.\n\n");
            continue;
        }

        switch (choice) {
            case 1:  do_launch_worker();    break;
            case 2:  do_list_workers();     break;
            case 3:  do_pause_worker();     break;
            case 4:  do_resume_worker();    break;
            case 5:  do_terminate_worker(); break;
            case 6:  do_restart_worker();   break;
            case 7:  do_process_info();     break;
            case 8:  do_view_log();         break;
            case 9:  print_help();          break;
            case 0:
                printf("  Exiting controller...\n");
                goto exit_loop;
            default:
                printf("  [!] Invalid choice '%d'. Enter 0–9.\n\n", choice);
                log_event("Invalid menu choice: %d", choice);
                break;
        }
    }

exit_loop:
    if (g_shutdown_requested)
        printf("\n  [Signal received — shutting down]\n");

    /* Clean up workers and log shutdown. */
    if (pm_count_active() > 0)
        pm_cleanup();

    log_event("Controller exiting normally");
    log_close();

    printf("\n  Activity log saved to: %s\n", LOG_FILE);
    printf("  Goodbye.\n\n");
    return EXIT_SUCCESS;
}
