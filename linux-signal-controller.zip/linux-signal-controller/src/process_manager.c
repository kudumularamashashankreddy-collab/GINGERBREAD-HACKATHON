/*
 * process_manager.c — Worker process lifecycle implementation.
 *
 * Manages fork/exec, SIGSTOP/SIGCONT/SIGTERM dispatch, and child reaping.
 */

#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include "process_manager.h"
#include "process_info.h"
#include "logger.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

/* ------------------------------------------------------------------ */
/* Worker table                                                          */
/* ------------------------------------------------------------------ */

static WorkerRecord g_workers[MAX_WORKERS];
static int          g_worker_count = 0;   /* number of slots ever used  */

/* ------------------------------------------------------------------ */
/* Internal helpers                                                     */
/* ------------------------------------------------------------------ */

/* Return a pointer to the WorkerRecord for pid, or NULL. */
static WorkerRecord *find_worker(pid_t pid)
{
    for (int i = 0; i < g_worker_count; i++) {
        if (g_workers[i].slot_used && g_workers[i].pid == pid)
            return &g_workers[i];
    }
    return NULL;
}

/* Return a pointer to an empty slot, or NULL if table is full. */
static WorkerRecord *alloc_slot(void)
{
    /* Prefer a REAPED slot. */
    for (int i = 0; i < g_worker_count; i++) {
        if (g_workers[i].state == WORKER_REAPED)
            return &g_workers[i];
    }
    if (g_worker_count < MAX_WORKERS)
        return &g_workers[g_worker_count++];
    return NULL;
}

static const char *state_label(WorkerState s)
{
    switch (s) {
        case WORKER_RUNNING:     return "RUNNING";
        case WORKER_STOPPED:     return "STOPPED";
        case WORKER_TERMINATING: return "TERMINATING";
        case WORKER_ZOMBIE:      return "ZOMBIE";
        case WORKER_REAPED:      return "REAPED";
        default:                 return "UNKNOWN";
    }
}

/* Sleep for ms milliseconds (busy-wait free). */
static void sleep_ms(int ms)
{
    struct timespec ts;
    ts.tv_sec  = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}

/*
 * safe_kill()
 *   Validate the PID before calling kill().
 *   Never signals PID 0, 1, or the controller itself.
 *   Returns the result of kill(), or -1 with errno set on validation failure.
 */
static int safe_kill(pid_t pid, int sig)
{
    if (pid <= 0) {
        fprintf(stderr, "  [!] Refusing to signal invalid PID %d\n", (int)pid);
        errno = EINVAL;
        return -1;
    }
    if (pid == 1) {
        fprintf(stderr, "  [!] Refusing to signal PID 1 (init/systemd)\n");
        errno = EPERM;
        return -1;
    }
    if (pid == getpid()) {
        fprintf(stderr, "  [!] Refusing to signal the controller itself (PID %d)\n",
                (int)pid);
        errno = EINVAL;
        return -1;
    }
    return kill(pid, sig);
}

/* ------------------------------------------------------------------ */
/* Public API                                                            */
/* ------------------------------------------------------------------ */

void pm_init(void)
{
    memset(g_workers, 0, sizeof(g_workers));
    g_worker_count = 0;
}

pid_t pm_launch_worker(const char *exe_path)
{
    /* Verify the executable exists before forking. */
    if (access(exe_path, X_OK) != 0) {
        fprintf(stderr, "  [!] Cannot execute '%s': %s\n",
                exe_path, strerror(errno));
        log_event("ERROR: worker executable '%s' not accessible: %s",
                  exe_path, strerror(errno));
        return -1;
    }

    WorkerRecord *slot = alloc_slot();
    if (slot == NULL) {
        fprintf(stderr, "  [!] Worker table is full (max %d workers)\n",
                MAX_WORKERS);
        log_event("ERROR: worker table full, cannot launch '%s'", exe_path);
        return -1;
    }

    pid_t child = fork();
    if (child < 0) {
        fprintf(stderr, "  [!] fork() failed: %s\n", strerror(errno));
        log_event("ERROR: fork() failed: %s", strerror(errno));
        return -1;
    }

    if (child == 0) {
        /*
         * Child process:
         *   exec() replaces our image with the worker binary.
         *   If exec() fails the child must exit — never return to the
         *   parent's code path.
         */
        execl(exe_path, exe_path, NULL);
        /* Only reached on exec failure. */
        perror("execl");
        _exit(127);   /* 127: command not found (POSIX convention) */
    }

    /* Parent: record the new worker. */
    memset(slot, 0, sizeof(*slot));
    slot->pid       = child;
    slot->state     = WORKER_RUNNING;
    slot->slot_used = 1;
    strncpy(slot->exe_path, exe_path, sizeof(slot->exe_path) - 1);

    log_worker_launch(child, exe_path);
    return child;
}

void pm_list_workers(void)
{
    int active = 0;
    for (int i = 0; i < g_worker_count; i++) {
        if (g_workers[i].slot_used && g_workers[i].state != WORKER_REAPED)
            active++;
    }

    if (active == 0) {
        printf("  No managed worker processes.\n");
        return;
    }

    printf("  %-8s  %-14s  %-10s  %s\n",
           "PID", "Logical State", "/proc State", "Executable");
    printf("  %-8s  %-14s  %-10s  %s\n",
           "--------", "--------------", "----------", "----------");

    for (int i = 0; i < g_worker_count; i++) {
        WorkerRecord *w = &g_workers[i];
        if (!w->slot_used || w->state == WORKER_REAPED)
            continue;

        char proc_state_str[16] = "N/A";
        char c = get_process_state_char(w->pid);
        if (c != '\0') {
            proc_state_str[0] = c;
            proc_state_str[1] = '\0';
        } else {
            strncpy(proc_state_str, "exited?", sizeof(proc_state_str) - 1);
        }

        printf("  %-8d  %-14s  %-10s  %s\n",
               (int)w->pid,
               state_label(w->state),
               proc_state_str,
               w->exe_path);
    }
}

int pm_pause_worker(pid_t pid)
{
    WorkerRecord *w = find_worker(pid);
    if (w == NULL) {
        printf("  [!] PID %d is not a managed worker.\n", (int)pid);
        printf("      Only workers launched by this controller can be paused.\n");
        log_event("PAUSE REJECTED: PID %d not in worker table", (int)pid);
        return -1;
    }
    if (w->state == WORKER_REAPED || w->state == WORKER_ZOMBIE) {
        printf("  [!] PID %d has already exited.\n", (int)pid);
        return -1;
    }
    if (w->state == WORKER_STOPPED) {
        printf("  [!] PID %d is already stopped.\n", (int)pid);
        return 0;
    }

    printf("  Sending SIGSTOP to PID %d ...\n", (int)pid);
    printf("  Note: SIGSTOP cannot be caught, blocked, or ignored by the target.\n");
    printf("        The kernel suspends the process unconditionally.\n");

    if (safe_kill(pid, SIGSTOP) != 0) {
        fprintf(stderr, "  [!] kill(SIGSTOP, %d): %s\n", (int)pid, strerror(errno));
        log_event("ERROR: SIGSTOP -> PID %d failed: %s", (int)pid, strerror(errno));
        return -1;
    }

    /* Brief wait then verify via /proc. */
    sleep_ms(100);
    char state = get_process_state_char(pid);
    if (state == 'T' || state == 't') {
        w->state = WORKER_STOPPED;
        printf("  [✓] PID %d confirmed STOPPED (/proc state: T)\n", (int)pid);
        log_signal_sent("SIGSTOP", pid);
    } else {
        printf("  [?] SIGSTOP sent; /proc state is '%c' (may take a moment)\n",
               state ? state : '?');
        w->state = WORKER_STOPPED;   /* trust our signal; kernel will stop it */
        log_signal_sent("SIGSTOP", pid);
    }
    return 0;
}

int pm_resume_worker(pid_t pid)
{
    WorkerRecord *w = find_worker(pid);
    if (w == NULL) {
        printf("  [!] PID %d is not a managed worker.\n", (int)pid);
        log_event("RESUME REJECTED: PID %d not in worker table", (int)pid);
        return -1;
    }
    if (w->state == WORKER_REAPED || w->state == WORKER_ZOMBIE) {
        printf("  [!] PID %d has already exited.\n", (int)pid);
        return -1;
    }
    if (w->state == WORKER_RUNNING) {
        printf("  [!] PID %d is not stopped (current state: %s).\n",
               (int)pid, state_label(w->state));
        return 0;
    }

    printf("  Sending SIGCONT to PID %d ...\n", (int)pid);
    printf("  Note: SIGCONT makes the process eligible to run;\n");
    printf("        the CPU scheduler decides when it actually executes.\n");

    if (safe_kill(pid, SIGCONT) != 0) {
        fprintf(stderr, "  [!] kill(SIGCONT, %d): %s\n", (int)pid, strerror(errno));
        log_event("ERROR: SIGCONT -> PID %d failed: %s", (int)pid, strerror(errno));
        return -1;
    }

    sleep_ms(150);
    char state = get_process_state_char(pid);
    if (state == 'S' || state == 'R') {
        w->state = WORKER_RUNNING;
        printf("  [✓] PID %d resumed (/proc state: %c)\n", (int)pid, state);
    } else {
        w->state = WORKER_RUNNING;
        printf("  [✓] SIGCONT sent to PID %d (/proc state: %c)\n",
               (int)pid, state ? state : '?');
    }
    log_signal_sent("SIGCONT", pid);
    return 0;
}

/*
 * Blocking wait with timeout: polls waitpid(WNOHANG) for up to
 * TERMINATE_TIMEOUT_SEC seconds.  Returns 1 if reaped, 0 on timeout.
 */
static int wait_for_exit(pid_t pid, int timeout_sec)
{
    for (int elapsed_ms = 0; elapsed_ms < timeout_sec * 1000; elapsed_ms += 100) {
        int status;
        pid_t result = waitpid(pid, &status, WNOHANG);
        if (result == pid) {
            WorkerRecord *w = find_worker(pid);
            if (w) w->state = WORKER_REAPED;
            log_process_exit(pid, status);
            return 1;
        }
        if (result < 0) {
            if (errno == ECHILD) {
                /* Already reaped elsewhere. */
                WorkerRecord *w = find_worker(pid);
                if (w) w->state = WORKER_REAPED;
                return 1;
            }
            break;
        }
        sleep_ms(100);
    }
    return 0;
}

int pm_terminate_worker(pid_t pid)
{
    WorkerRecord *w = find_worker(pid);
    if (w == NULL) {
        printf("  [!] PID %d is not a managed worker.\n", (int)pid);
        log_event("TERMINATE REJECTED: PID %d not in worker table", (int)pid);
        return -1;
    }
    if (w->state == WORKER_REAPED) {
        printf("  [!] PID %d has already been reaped.\n", (int)pid);
        return 0;
    }

    /*
     * If the process is stopped (SIGSTOP'd), it cannot receive SIGTERM until
     * it is resumed.  Send SIGCONT first so it can process SIGTERM.
     */
    if (w->state == WORKER_STOPPED) {
        printf("  [i] Process is stopped; sending SIGCONT before SIGTERM.\n");
        safe_kill(pid, SIGCONT);
        sleep_ms(50);
    }

    printf("  Sending SIGTERM to PID %d ...\n", (int)pid);
    printf("  Note: SIGTERM can be caught or ignored by the process.\n");
    printf("        We wait up to %d seconds for it to exit.\n",
           TERMINATE_TIMEOUT_SEC);

    if (safe_kill(pid, SIGTERM) != 0) {
        fprintf(stderr, "  [!] kill(SIGTERM, %d): %s\n", (int)pid, strerror(errno));
        log_event("ERROR: SIGTERM -> PID %d failed: %s", (int)pid, strerror(errno));
        return -1;
    }

    log_signal_sent("SIGTERM", pid);
    w->state = WORKER_TERMINATING;

    printf("  Waiting for PID %d to exit (timeout: %ds) ...\n",
           (int)pid, TERMINATE_TIMEOUT_SEC);

    if (wait_for_exit(pid, TERMINATE_TIMEOUT_SEC)) {
        printf("  [✓] PID %d has exited.\n", (int)pid);
        log_event("Worker PID %d terminated successfully", (int)pid);
        return 0;
    }

    printf("  [!] PID %d did not exit within %d seconds.\n",
           (int)pid, TERMINATE_TIMEOUT_SEC);
    printf("      The process may be ignoring SIGTERM.  You may need to\n");
    printf("      terminate it manually (SIGKILL is NOT sent automatically).\n");
    log_event("WARNING: PID %d did not exit within %ds after SIGTERM",
              (int)pid, TERMINATE_TIMEOUT_SEC);
    return -1;
}

pid_t pm_restart_worker(pid_t old_pid)
{
    WorkerRecord *w = find_worker(old_pid);
    if (w == NULL) {
        printf("  [!] PID %d is not a managed worker.\n", (int)old_pid);
        log_event("RESTART REJECTED: PID %d not in worker table", (int)old_pid);
        return -1;
    }
    if (w->state == WORKER_REAPED) {
        printf("  [!] PID %d has already exited; cannot restart.\n", (int)old_pid);
        return -1;
    }

    char exe_path[256];
    strncpy(exe_path, w->exe_path, sizeof(exe_path) - 1);
    exe_path[sizeof(exe_path) - 1] = '\0';

    printf("  Restarting worker (old PID: %d) ...\n", (int)old_pid);
    printf("  Note: Restart is an APPLICATION-level operation — not a Linux signal.\n");
    printf("        We terminate the old process, wait for it to exit, then\n");
    printf("        launch a brand-new process.  The new PID will be different.\n\n");

    log_event("RESTART: requesting old worker PID %d to terminate", (int)old_pid);

    /* Step 1: terminate old worker. */
    if (pm_terminate_worker(old_pid) != 0) {
        printf("  [!] Old worker PID %d did not exit cleanly.\n", (int)old_pid);
        printf("      Aborting restart to avoid running duplicate workers.\n");
        log_event("RESTART ABORTED: old worker PID %d did not exit", (int)old_pid);
        return -1;
    }

    /* Step 2: launch new worker. */
    pid_t new_pid = pm_launch_worker(exe_path);
    if (new_pid < 0) {
        printf("  [!] Failed to launch replacement worker.\n");
        log_event("RESTART FAILED: could not launch new worker for '%s'", exe_path);
        return -1;
    }

    printf("\n  [✓] Restart complete:\n");
    printf("      Old PID : %d (terminated and reaped)\n", (int)old_pid);
    printf("      New PID : %d (running)\n", (int)new_pid);
    log_event("RESTART OK: old PID %d replaced by new PID %d  exe='%s'",
              (int)old_pid, (int)new_pid, exe_path);
    return new_pid;
}

void pm_reap_children(void)
{
    for (;;) {
        int    status;
        pid_t  pid = waitpid(-1, &status, WNOHANG);
        if (pid <= 0)
            break;   /* no more exited children right now */

        WorkerRecord *w = find_worker(pid);
        if (w) {
            w->state = WORKER_REAPED;
        }
        log_process_exit(pid, status);
    }
}

void pm_cleanup(void)
{
    printf("\n  Cleaning up managed workers ...\n");
    for (int i = 0; i < g_worker_count; i++) {
        WorkerRecord *w = &g_workers[i];
        if (!w->slot_used || w->state == WORKER_REAPED)
            continue;

        if (w->state == WORKER_STOPPED) {
            safe_kill(w->pid, SIGCONT);
            sleep_ms(50);
        }
        printf("  Sending SIGTERM to worker PID %d ...\n", (int)w->pid);
        safe_kill(w->pid, SIGTERM);
        log_signal_sent("SIGTERM (cleanup)", w->pid);
    }

    /* Give all workers a moment, then reap. */
    sleep_ms(TERMINATE_TIMEOUT_SEC * 1000 / 2);

    for (int i = 0; i < g_worker_count; i++) {
        WorkerRecord *w = &g_workers[i];
        if (!w->slot_used || w->state == WORKER_REAPED)
            continue;

        int status;
        pid_t result = waitpid(w->pid, &status, WNOHANG);
        if (result == w->pid) {
            w->state = WORKER_REAPED;
            log_process_exit(w->pid, status);
        } else {
            printf("  [!] Worker PID %d did not exit; it may remain running.\n",
                   (int)w->pid);
            log_event("WARNING: worker PID %d did not exit during cleanup",
                      (int)w->pid);
        }
    }
}

int pm_count_active(void)
{
    int count = 0;
    for (int i = 0; i < g_worker_count; i++) {
        if (g_workers[i].slot_used && g_workers[i].state != WORKER_REAPED)
            count++;
    }
    return count;
}
