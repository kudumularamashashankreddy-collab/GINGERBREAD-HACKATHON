/*
 * signal_handler.c — Controller-side signal handling implementation.
 *
 * The signal handlers below are intentionally minimal:
 *   - They set a volatile sig_atomic_t flag.
 *   - They call no library functions that are not async-signal-safe.
 *   - All subsequent work (reaping, logging, cleanup) is done in main loop
 *     context, where the full C library is available.
 */

#define _POSIX_C_SOURCE 200809L

#include "signal_handler.h"

#include <stdio.h>
#include <string.h>
#include <errno.h>

/* --------------------------------------------------------------------- */
/* Global flag variables (definitions)                                     */
/* --------------------------------------------------------------------- */

volatile sig_atomic_t g_shutdown_requested = 0;
volatile sig_atomic_t g_child_exited       = 0;

/* --------------------------------------------------------------------- */
/* Internal handlers (async-signal-safe only)                              */
/* --------------------------------------------------------------------- */

/*
 * handle_shutdown()
 *   Triggered by SIGINT (Ctrl-C) or SIGTERM directed at the controller.
 *   Only sets the shutdown flag; the main loop handles graceful exit.
 */
static void handle_shutdown(int signo)
{
    (void)signo;
    g_shutdown_requested = 1;
}

/*
 * handle_sigchld()
 *   Triggered whenever a child process changes state (exits, is stopped, etc.).
 *   Sets g_child_exited so the main loop can call waitpid() at a safe point.
 *
 *   Note: we do NOT call waitpid() here because:
 *   1. waitpid() is async-signal-safe but can complicate application logic.
 *   2. Multiple SIGCHLD signals may be coalesced into one delivery; all
 *      pending children are reaped in the main loop using a loop.
 */
static void handle_sigchld(int signo)
{
    (void)signo;
    g_child_exited = 1;
}

/* --------------------------------------------------------------------- */
/* Public API                                                               */
/* --------------------------------------------------------------------- */

int signals_init(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));

    /*
     * SIGINT / SIGTERM → graceful controller shutdown.
     * SA_RESTART: automatically restart interrupted system calls where safe.
     */
    sa.sa_handler = handle_shutdown;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;

    if (sigaction(SIGINT, &sa, NULL) != 0) {
        perror("sigaction(SIGINT)");
        return -1;
    }
    if (sigaction(SIGTERM, &sa, NULL) != 0) {
        perror("sigaction(SIGTERM)");
        return -1;
    }

    /*
     * SIGCHLD → notification that a child changed state.
     * SA_NOCLDSTOP: suppress SIGCHLD for stop events (we only care about exit
     *               for automatic reaping; explicit pause/resume uses SIGSTOP
     *               and SIGCONT directly via kill()).
     * SA_RESTART:   restart interrupted calls.
     */
    sa.sa_handler = handle_sigchld;
    sa.sa_flags   = SA_RESTART | SA_NOCLDSTOP;
    if (sigaction(SIGCHLD, &sa, NULL) != 0) {
        perror("sigaction(SIGCHLD)");
        return -1;
    }

    /*
     * SIGPIPE → ignore; avoids crashing if a pipe or socket closes unexpectedly.
     */
    sa.sa_handler = SIG_IGN;
    sa.sa_flags   = 0;
    if (sigaction(SIGPIPE, &sa, NULL) != 0) {
        perror("sigaction(SIGPIPE)");
        return -1;
    }

    return 0;
}
