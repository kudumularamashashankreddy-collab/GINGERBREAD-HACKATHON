/*
 * process_manager.h — Lifecycle management for worker processes.
 *
 * Manages a table of worker records.  Each record stores:
 *   - The worker PID.
 *   - The path to the worker executable (needed to restart).
 *   - A logical state (RUNNING, STOPPED, TERMINATED, ZOMBIE, REAPED).
 *
 * DESIGN NOTES:
 *
 * 1. fork() + exec():
 *    fork() creates a child that is a copy of the parent's address space.
 *    exec() replaces the child's image with the worker binary.
 *    Together they are the standard POSIX way to launch a new program.
 *
 * 2. Restart is an application-level operation:
 *    Linux has no "restart signal".  Restart means:
 *      a. Terminate the old worker (SIGTERM + wait).
 *      b. fork() + exec() a new worker.
 *    The new worker gets a new PID.  The old process is gone.
 *
 * 3. PID reuse race:
 *    After a child exits it is reaped with waitpid().  Between exit and
 *    reaping the PID exists in zombie state; afterwards the PID may be
 *    reused by the kernel for an unrelated process.  We track whether each
 *    child has been reaped and refuse to signal a reaped PID.
 *
 * 4. SIGSTOP / SIGKILL:
 *    These cannot be caught or ignored by the target process; the kernel
 *    enforces them directly.  Sending them via kill() returns success if
 *    the signal was delivered; it does not wait for the process to stop/die.
 */

#ifndef PROCESS_MANAGER_H
#define PROCESS_MANAGER_H

#include <sys/types.h>

/* Maximum number of simultaneously tracked workers. */
#define MAX_WORKERS 32

/* Path to the worker executable (relative to controller working directory). */
#define WORKER_EXE "build/worker"

/* ------------------------------------------------------------------ */
/* Worker logical states                                                */
/* ------------------------------------------------------------------ */
typedef enum {
    WORKER_RUNNING    = 0,  /* forked and running (or sleeping normally) */
    WORKER_STOPPED    = 1,  /* paused with SIGSTOP                       */
    WORKER_TERMINATING= 2,  /* SIGTERM sent, waiting for exit            */
    WORKER_ZOMBIE     = 3,  /* exited but not yet reaped                 */
    WORKER_REAPED     = 4   /* waitpid() completed — slot may be reused  */
} WorkerState;

/* ------------------------------------------------------------------ */
/* Worker record                                                         */
/* ------------------------------------------------------------------ */
typedef struct {
    pid_t       pid;
    WorkerState state;
    char        exe_path[256];  /* path used to exec this worker          */
    int         slot_used;      /* 1 = this slot is in use                */
} WorkerRecord;

/* ------------------------------------------------------------------ */
/* Public API                                                            */
/* ------------------------------------------------------------------ */

/*
 * pm_init()
 *   Initialise the worker table.  Call once at startup.
 */
void pm_init(void);

/*
 * pm_launch_worker(exe_path)
 *   fork() + exec() a new worker from exe_path.
 *   Records the new PID in the worker table.
 *   Returns the new PID on success, -1 on failure.
 */
pid_t pm_launch_worker(const char *exe_path);

/*
 * pm_list_workers()
 *   Print all tracked workers with their PID and logical state.
 *   Refreshes state from /proc before printing.
 */
void pm_list_workers(void);

/*
 * pm_pause_worker(pid)
 *   Send SIGSTOP to the specified PID.
 *   Verifies the PID is a managed worker.
 *   Returns 0 on success, -1 on failure.
 */
int pm_pause_worker(pid_t pid);

/*
 * pm_resume_worker(pid)
 *   Send SIGCONT to the specified PID.
 *   Returns 0 on success, -1 on failure.
 */
int pm_resume_worker(pid_t pid);

/*
 * pm_terminate_worker(pid)
 *   Send SIGTERM to the specified PID.
 *   Waits up to TERMINATE_TIMEOUT_SEC for the process to exit.
 *   Does NOT automatically escalate to SIGKILL.
 *   Returns 0 if the process exited within the timeout, -1 otherwise.
 */
int pm_terminate_worker(pid_t pid);

/*
 * pm_restart_worker(pid)
 *   Terminate the old worker identified by pid, wait for it to be reaped,
 *   then launch a new instance using the same executable path.
 *   Prints the old PID and the new PID.
 *   Returns the new PID on success, -1 on failure.
 */
pid_t pm_restart_worker(pid_t pid);

/*
 * pm_reap_children()
 *   Non-blocking loop calling waitpid(WNOHANG) to collect any children
 *   that have already exited.  Updates worker table states.
 *   Call this from the main loop when g_child_exited is set.
 */
void pm_reap_children(void);

/*
 * pm_cleanup()
 *   Send SIGTERM to all still-running managed workers and wait for them.
 *   Called during controller shutdown.
 */
void pm_cleanup(void);

/*
 * pm_count_active()
 *   Returns the number of workers not yet reaped.
 */
int pm_count_active(void);

/* Timeout (seconds) used in pm_terminate_worker(). */
#define TERMINATE_TIMEOUT_SEC 5

#endif /* PROCESS_MANAGER_H */
