/*
 * logger.h — Timestamped activity logger for Linux Signal-Based Process Controller
 *
 * Records controller events to logs/activity.log with ISO-8601 timestamps.
 * All log operations are safe to call from normal (non-signal-handler) context.
 */

#ifndef LOGGER_H
#define LOGGER_H

#include <sys/types.h>   /* pid_t */

/* Default log file path (relative to working directory at startup). */
#define LOG_DIR      "logs"
#define LOG_FILE     "logs/activity.log"

/*
 * log_init()
 *   Open (or create) the log file and write a startup banner.
 *   Creates LOG_DIR if it does not exist.
 *   Returns 0 on success, -1 on failure.
 */
int  log_init(void);

/*
 * log_close()
 *   Write a shutdown banner and close the log file.
 */
void log_close(void);

/*
 * log_event(fmt, ...)
 *   Write a timestamped formatted message to the log.
 *   Silently continues if the log file is not open.
 */
void log_event(const char *fmt, ...)
    __attribute__((format(printf, 1, 2)));

/*
 * log_worker_launch(pid, path)
 *   Convenience: log a worker launch with its PID and executable path.
 */
void log_worker_launch(pid_t pid, const char *path);

/*
 * log_signal_sent(signal_name, target_pid)
 *   Convenience: log a signal dispatch.
 */
void log_signal_sent(const char *signal_name, pid_t target_pid);

/*
 * log_process_exit(pid, status)
 *   Convenience: log a collected child exit.
 */
void log_process_exit(pid_t pid, int status);

#endif /* LOGGER_H */
