/*
 * process_info.h — /proc-based process information reader.
 *
 * Reads from /proc/<PID>/stat and /proc/<PID>/status to retrieve
 * process state, name, and other metadata.
 *
 * PARSING /proc/<PID>/stat CORRECTLY:
 *   Field 2 is the process name in parentheses, e.g. "(my prog)".
 *   The name may contain spaces and parentheses.  We locate the LAST ')'
 *   in the line and parse fields 3 onwards from there.
 *
 * PROCESS STATES (field 3 of /proc/<PID>/stat):
 *   R  — Running or runnable (on run queue)
 *   S  — Interruptible sleep (waiting for an event)
 *   D  — Uninterruptible sleep (usually I/O)
 *   T  — Stopped by a signal (SIGSTOP / SIGTSTP) or by a tracer
 *   t  — Tracing stop (ptrace)
 *   Z  — Zombie (exited but not yet reaped by parent)
 *   X  — Dead (should never appear in /proc)
 */

#ifndef PROCESS_INFO_H
#define PROCESS_INFO_H

#include <sys/types.h>

/* Maximum length for process name storage. */
#define PROC_NAME_MAX 256

/*
 * ProcessInfo — populated by get_process_info().
 */
typedef struct {
    pid_t  pid;
    char   name[PROC_NAME_MAX];   /* comm field from /proc/<PID>/stat     */
    char   state;                 /* single character: R, S, D, T, Z, X … */
    char   state_desc[64];        /* human-readable state description      */
    int    valid;                 /* 1 if successfully read, 0 otherwise   */
    char   error_msg[128];        /* populated when valid == 0             */
} ProcessInfo;

/*
 * get_process_info(pid, info)
 *   Populate *info from /proc/<pid>/stat.
 *   Sets info->valid = 1 on success, 0 on any error (permission, nonexistent).
 */
void get_process_info(pid_t pid, ProcessInfo *info);

/*
 * print_process_info(info)
 *   Print a formatted summary of *info to stdout.
 *   Explains process state to the user.
 */
void print_process_info(const ProcessInfo *info);

/*
 * process_exists(pid)
 *   Returns 1 if /proc/<pid> is accessible, 0 otherwise.
 *   NOTE: Existence does not imply health or permission to signal.
 *         There is an inherent TOCTOU race between checking and signalling.
 */
int process_exists(pid_t pid);

/*
 * get_process_state_char(pid)
 *   Returns the state character from /proc/<pid>/stat, or '\0' on error.
 */
char get_process_state_char(pid_t pid);

#endif /* PROCESS_INFO_H */
