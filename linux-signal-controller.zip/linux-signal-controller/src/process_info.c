/*
 * process_info.c — /proc-based process information implementation.
 */

#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include "process_info.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

/* ------------------------------------------------------------------ */
/* State description helper                                             */
/* ------------------------------------------------------------------ */

static const char *state_description(char s)
{
    switch (s) {
        case 'R': return "Running or runnable (on run queue)";
        case 'S': return "Sleeping (interruptible — waiting for event)";
        case 'D': return "Disk sleep (uninterruptible — usually I/O)";
        case 'T': return "Stopped (received SIGSTOP or SIGTSTP)";
        case 't': return "Tracing stop (being debugged with ptrace)";
        case 'Z': return "Zombie (exited, waiting to be reaped by parent)";
        case 'X': return "Dead (should not appear in /proc)";
        case 'I': return "Idle kernel thread";
        default:  return "Unknown state";
    }
}

/* ------------------------------------------------------------------ */
/* /proc/<pid>/stat parser                                              */
/* ------------------------------------------------------------------ */

/*
 * parse_proc_stat()
 *   Parse a single line from /proc/<pid>/stat.
 *
 *   The format is:
 *     <pid> (<comm>) <state> <ppid> ...
 *
 *   The comm field (process name) is wrapped in parentheses and may
 *   itself contain parentheses and spaces.  We locate the LAST ')'
 *   in the line to find where the comm field ends, then read the
 *   state character from the token that follows.
 *
 *   Returns 1 on success, 0 on parse failure.
 */
static int parse_proc_stat(const char *line, char *name_out, size_t name_max,
                            char *state_out)
{
    /* Find first '(' */
    const char *paren_open = strchr(line, '(');
    if (paren_open == NULL)
        return 0;

    /* Find last ')' — handles names containing ')' */
    const char *paren_close = strrchr(line, ')');
    if (paren_close == NULL || paren_close <= paren_open)
        return 0;

    /* Copy name between the parentheses. */
    size_t name_len = (size_t)(paren_close - paren_open - 1);
    if (name_len >= name_max)
        name_len = name_max - 1;
    memcpy(name_out, paren_open + 1, name_len);
    name_out[name_len] = '\0';

    /* State character follows ") ", so skip ") ". */
    const char *after = paren_close + 1;
    while (*after == ' ')
        after++;
    if (*after == '\0')
        return 0;

    *state_out = *after;
    return 1;
}

/* ------------------------------------------------------------------ */
/* Public API                                                            */
/* ------------------------------------------------------------------ */

void get_process_info(pid_t pid, ProcessInfo *info)
{
    char path[64];
    FILE *fp;
    char line[1024];

    memset(info, 0, sizeof(*info));
    info->pid   = pid;
    info->valid = 0;

    /* Basic sanity. */
    if (pid <= 0) {
        snprintf(info->error_msg, sizeof(info->error_msg),
                 "Invalid PID %d", (int)pid);
        return;
    }

    snprintf(path, sizeof(path), "/proc/%d/stat", (int)pid);

    fp = fopen(path, "r");
    if (fp == NULL) {
        if (errno == ENOENT)
            snprintf(info->error_msg, sizeof(info->error_msg),
                     "PID %d does not exist (process has exited)", (int)pid);
        else if (errno == EACCES || errno == EPERM)
            snprintf(info->error_msg, sizeof(info->error_msg),
                     "PID %d: permission denied (try as root)", (int)pid);
        else
            snprintf(info->error_msg, sizeof(info->error_msg),
                     "PID %d: cannot open /proc: %s", (int)pid, strerror(errno));
        return;
    }

    if (fgets(line, sizeof(line), fp) == NULL) {
        snprintf(info->error_msg, sizeof(info->error_msg),
                 "PID %d: failed to read /proc/%d/stat: %s",
                 (int)pid, (int)pid, strerror(errno));
        fclose(fp);
        return;
    }
    fclose(fp);

    /* Remove trailing newline. */
    size_t len = strlen(line);
    if (len > 0 && line[len - 1] == '\n')
        line[len - 1] = '\0';

    char state = '?';
    if (!parse_proc_stat(line, info->name, sizeof(info->name), &state)) {
        snprintf(info->error_msg, sizeof(info->error_msg),
                 "PID %d: failed to parse /proc/%d/stat", (int)pid, (int)pid);
        return;
    }

    info->state = state;
    strncpy(info->state_desc, state_description(state),
            sizeof(info->state_desc) - 1);
    info->state_desc[sizeof(info->state_desc) - 1] = '\0';
    info->valid = 1;
}

void print_process_info(const ProcessInfo *info)
{
    if (!info->valid) {
        printf("  [!] Unable to retrieve info: %s\n", info->error_msg);
        printf("  Note: A process may exit between the time we check and\n"
               "        the time we read /proc — this is a normal race condition.\n");
        return;
    }

    printf("  ┌──────────────────────────────────────────────┐\n");
    printf("  │  PID   : %-36d│\n", (int)info->pid);
    printf("  │  Name  : %-36s│\n", info->name);
    printf("  │  State : %c  %-33s│\n", info->state, info->state_desc);
    printf("  └──────────────────────────────────────────────┘\n");
    printf("\n");
    printf("  Process state interpretation:\n");
    printf("    R = On run queue (actively using or waiting for CPU)\n");
    printf("    S = Sleeping (blocked on I/O, timer, or synchronisation)\n");
    printf("    T = Stopped (SIGSTOP received — cannot be caught or ignored)\n");
    printf("    Z = Zombie (exited but parent has not called wait() yet)\n");
    printf("\n");
    printf("  IMPORTANT: State alone does not confirm that the application\n");
    printf("  is working correctly.  A process in state 'S' may be\n");
    printf("  perfectly healthy or silently deadlocked.\n");
}

int process_exists(pid_t pid)
{
    char path[64];
    struct stat st;
    snprintf(path, sizeof(path), "/proc/%d", (int)pid);
    return (stat(path, &st) == 0) ? 1 : 0;
}

char get_process_state_char(pid_t pid)
{
    ProcessInfo info;
    get_process_info(pid, &info);
    if (info.valid)
        return info.state;
    return '\0';
}
